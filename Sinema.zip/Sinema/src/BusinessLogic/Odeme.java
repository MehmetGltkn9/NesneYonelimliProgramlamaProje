package BusinessLogic;

public abstract class Odeme {
    private String odemeAdi;
    private float odemeTutari;
    public abstract void OdemeYap();
    public abstract void OdemeSorgula();

    public String getOdemeAdi() {
        return odemeAdi;
    }

    public void setOdemeAdi(String odemeAdi) {
        this.odemeAdi = odemeAdi;
    }

    public float getOdemeTutari() {
        return odemeTutari;
    }

    public void setOdemeTutari(float odemeTutari) {
        this.odemeTutari = odemeTutari;
    }
    
}
