
package BusinessLogic;
public class Koltuk {
    private int koltukNo;
    private boolean dolu;
    private Salon salon;
    
    public Koltuk(){
        
    }
    public Koltuk(int koltukNo, Salon salon) {
        this.koltukNo = koltukNo;
        this.dolu = false;
        this.salon = salon;
    }

    public Salon getSalon() {
        return salon;
    }

    public void setSalon(Salon salon) {
        this.salon = salon;
    }

    public int getKoltukNo() {
        return koltukNo;
    }

    public void setKoltukNo(int koltukNo) {
        this.koltukNo = koltukNo;
    }

    public boolean isDolu() {
        return dolu;
    }

    public void setDolu(boolean dolu) {
        this.dolu = dolu;
    }
    
    public void KoltukRezerveEt(){
        
    }
    
    public void KoltukIptalEt(){
        
    }
    
    public void KoltukBilgileri(){
        
    }
}
