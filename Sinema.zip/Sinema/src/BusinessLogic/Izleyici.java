package BusinessLogic;
public class Izleyici {
    private String izleyiciAdSoyad;
    private char izleyiciCinsiyeti;
    private String izleyiciTuru;
    private String izleyiciE_Mail;
    private String izleyiciTelefonNo;
    private Bilet izleyiciBilet;

    public Izleyici() {
        
    }

    public Izleyici(String izleyiciAdSoyad, char izleyiciCinsiyeti, String izleyiciTuru, String izleyiciE_Mail, String izleyiciTelefonNo, Bilet izleyiciBilet) {
        this.izleyiciAdSoyad = izleyiciAdSoyad;
        this.izleyiciCinsiyeti = izleyiciCinsiyeti;
        this.izleyiciTuru = izleyiciTuru;
        this.izleyiciE_Mail = izleyiciE_Mail;
        this.izleyiciTelefonNo = izleyiciTelefonNo;
        this.izleyiciBilet = izleyiciBilet;
    }

    public Bilet getIzleyiciBilet() {
        return izleyiciBilet;
    }

    public void setIzleyiciBilet(Bilet izleyiciBilet) {
        this.izleyiciBilet = izleyiciBilet;
    }

    public String getIzleyiciAdSoyad() {
        return izleyiciAdSoyad;
    }

    public void setIzleyiciAdSoyad(String izleyiciAdSoyad) {
        this.izleyiciAdSoyad = izleyiciAdSoyad;
    }

    public char getIzleyiciCinsiyeti() {
        return izleyiciCinsiyeti;
    }

    public void setIzleyiciCinsiyeti(char izleyiciCinsiyeti) {
        this.izleyiciCinsiyeti = izleyiciCinsiyeti;
    }

    public String getIzleyiciTuru() {
        return izleyiciTuru;
    }

    public void setIzleyiciTuru(String izleyiciTuru) {
        this.izleyiciTuru = izleyiciTuru;
    }

    public String getIzleyiciE_Mail() {
        return izleyiciE_Mail;
    }

    public void setIzleyiciE_Mail(String izleyiciE_Mail) {
        this.izleyiciE_Mail = izleyiciE_Mail;
    }

    public String getIzleyiciTelefonNo() {
        return izleyiciTelefonNo;
    }

    public void setIzleyiciTelefonNo(String izleyiciTelefonNo) {
        this.izleyiciTelefonNo = izleyiciTelefonNo;
    }
    
    public void BiletSatinAl(){
        
    }
    
    public void BiletIptal(){
        
    }
    
    public void IzleyiciBilgileri(){
        
    }
    
}
