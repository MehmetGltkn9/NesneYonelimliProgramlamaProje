package BusinessLogic;

public class MobilOdeme extends Odeme{
    
    @Override
    public void OdemeYap() {
        
    }

    @Override
    public void OdemeSorgula() {
        
    }
    
}
