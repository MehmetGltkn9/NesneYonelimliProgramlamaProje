package BusinessLogic;

public class KrediKartiOdeme extends Odeme{
    
    @Override
    public void OdemeYap() {
        
    }

    @Override
    public void OdemeSorgula() {
        
    }
    
}
