package BusinessLogic;

import java.util.ArrayList;

public class Salon {
    private int salonNo;
    private String salonTuru;
    private int izleyiciKapasitesi;
    private ArrayList<Seans> seanslar; 

    public Salon() {
        
    }

    public Salon(int salonNo, String salonTuru, int izleyiciKapasitesi, ArrayList<Seans> seanslar) {
        this.salonNo = salonNo;
        this.salonTuru = salonTuru;
        this.izleyiciKapasitesi = izleyiciKapasitesi;
        this.seanslar = seanslar;
    }

    public ArrayList<Seans> getSeanslar() {
        return seanslar;
    }

    public void setSeanslar(ArrayList<Seans> seanslar) {
        this.seanslar = seanslar;
    }

    public int getSalonNo() {
        return salonNo;
    }

    public void setSalonNo(int salonNo) {
        this.salonNo = salonNo;
    }

    public String getSalonTuru() {
        return salonTuru;
    }

    public void setSalonTuru(String salonTuru) {
        this.salonTuru = salonTuru;
    }

    public int getIzleyiciKapasitesi() {
        return izleyiciKapasitesi;
    }

    public void setIzleyiciKapasitesi(int izleyiciKapasitesi) {
        this.izleyiciKapasitesi = izleyiciKapasitesi;
    }
    
    private void SeansEkle(){
        
    }
    
    private void SeansSil(){
        
    }
    
    private void SeansBilgisi(){
        
    }
}
