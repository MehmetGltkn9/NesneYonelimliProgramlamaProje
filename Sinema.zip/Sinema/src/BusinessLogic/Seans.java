package BusinessLogic;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Seans {
    private Film film;
    private Salon salon;
    private LocalDateTime tarihSaat;
    private int kontenjan;
    private int doluluk;
    private ArrayList<Bilet> biletler;

    public Seans() {
    }

    public Seans(Film film, Salon salon, LocalDateTime tarihSaat, int kontenjan, int doluluk, ArrayList<Bilet> biletler) {
        this.film = film;
        this.salon = salon;
        this.tarihSaat = tarihSaat;
        this.kontenjan = kontenjan;
        this.doluluk = doluluk;
        this.biletler = biletler;
    }

    public Film getFilm() {
        return film;
    }

    public void setFilm(Film film) {
        this.film = film;
    }

    public Salon getSalon() {
        return salon;
    }

    public void setSalon(Salon salon) {
        this.salon = salon;
    }

    public LocalDateTime getTarihSaat() {
        return tarihSaat;
    }

    public void setTarihSaat(LocalDateTime tarihSaat) {
        this.tarihSaat = tarihSaat;
    }

    public int getKontenjan() {
        return kontenjan;
    }

    public void setKontenjan(int kontenjan) {
        this.kontenjan = kontenjan;
    }

    public int getDoluluk() {
        return doluluk;
    }

    public void setDoluluk(int doluluk) {
        this.doluluk = doluluk;
    }

    public ArrayList<Bilet> getBiletler() {
        return biletler;
    }

    public void setBiletler(ArrayList<Bilet> biletler) {
        this.biletler = biletler;
    }
    
    private void BiletAl(){
        
    }
    private void BiletIptal(){
        
    }
    private void SeansBilgisi(){
        
    }
}
