package BusinessLogic;
import java.util.Date;
import java.util.Scanner;
public class Bilet {
    private Izleyici biletSahibi;
    private Koltuk koltuk;
    private Film biletFilm;
    private Date biletSeansSaati;
    private int biletNo;
    private float biletFiyat;

    public Bilet() {
        
    }
   
    public Bilet(Izleyici biletSahibi, Koltuk koltuk, int koltukNo,
    Film biletFilm, Date biletTarihi, int biletNo, float biletFiyat) {
        this.biletSahibi = biletSahibi;
        this.koltuk = koltuk;
        this.biletFilm = biletFilm;
        this.biletSeansSaati = biletTarihi;
        this.biletNo = biletNo;
        this.biletFiyat = biletFiyat;
    }

    public float getBiletFiyat() {
        return biletFiyat;
    }

    public void setBiletFiyat(float biletFiyat) {
        this.biletFiyat = biletFiyat;
    }

    public Izleyici getBiletSahibi() {
        return biletSahibi;
    }

    public void setBiletSahibi(Izleyici biletSahibi) {
        this.biletSahibi = biletSahibi;
    }

    public Koltuk getKoltuk() {
        return koltuk;
    }

    public void setKoltuk(Koltuk koltuk) {
        this.koltuk = koltuk;
    }

    public Film getBiletFilm() {
        return biletFilm;
    }

    public void setBiletFilm(Film biletFilm) {
        this.biletFilm = biletFilm;
    }

    public Date getBiletSeansSaati() {
        return biletSeansSaati;
    }

    public void setBiletSeansSaati(Date biletSeansSaati) {
        this.biletSeansSaati = biletSeansSaati;
    }

    public int getBiletNo() {
        return biletNo;
    }
    
    public void setBiletNo(int biletNo) {
        this.biletNo = biletNo;
    }
    
    public void OdemeYap(){
        Odeme odeme;
        System.out.println("Ödeme Türünü seçiniz:");
        System.out.println("1.Kredi kartıyla");
        System.out.println("2.Nakitle");
        System.out.println("3.Mobil");
        Scanner scan = new Scanner(System.in);
        int islem = scan.nextInt();
        switch (islem) {
            case 1:
                odeme = new KrediKartiOdeme();
                break;
            case 2:
                odeme = new NakitOdeme();
                break;
            default:
                odeme = new MobilOdeme();
                break;
        }
        
    }
    
    public void BiletBilgileri(){
        
    }
}
