package Main;

import GUI.AdminAnaEkran;
import GUI.AdminFilmEkran;
import GUI.GirisEkrani;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
    
    public static void main(String[] args) {
               
        GirisEkrani girisEkrani =  new GirisEkrani();
        
    }
    
}
