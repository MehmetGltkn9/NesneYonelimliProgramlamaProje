package Main;

import BusinessLogic.Film;
import BusinessLogic.Salon;
import BusinessLogic.Sinema;
import GUI.GirisEkrani;
import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        
        GirisEkrani girisEkrani =  new GirisEkrani();
        
//        Scanner scan = new Scanner(System.in);
//        Sinema sinema = new Sinema();
//        System.out.println("Sinema Adını giriniz:");
//        sinema.setSinemaAdi(scan.next());
//        System.out.println("Salon sayısını giriniz:");
//        int salonSayisi = scan.nextInt();
//        sinema.setSalonSayisi(salonSayisi);
//        Salon salonlar[] = new Salon[salonSayisi];
//        for(int i=0;i<salonSayisi;i++){
//            salonlar[i] = new Salon();
//            salonlar[i].setSalonNo(i+1);
//            System.out.println("Salon"+(i+1)+" in türünü giriniz:");
//            salonlar[i].setSalonTuru(scan.next());
//            System.out.println("Salon"+(i+1)+" in İzleyici kapasitesini giriniz:");
//            salonlar[i].setIzleyiciKapasitesi(scan.nextInt());
//        }
//        Film film = new Film();
        
    }
    
}
