package Action;

import GUI.AdminSinemaEkran;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminSinemaEkranAction implements ActionListener{
    AdminSinemaEkran adminAnaEkran;
    public AdminSinemaEkranAction(AdminSinemaEkran adminAnaEkran) {
        this.adminAnaEkran = adminAnaEkran;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
