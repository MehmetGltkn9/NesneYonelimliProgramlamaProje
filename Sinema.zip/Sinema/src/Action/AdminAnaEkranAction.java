package Action;

import GUI.AdminAnaEkran;
import GUI.AdminSinemaEkran;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminAnaEkranAction implements ActionListener{
    AdminAnaEkran adminAnaEkran;

    public AdminAnaEkranAction(AdminAnaEkran adminAnaEkran) {
        this.adminAnaEkran = adminAnaEkran;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == adminAnaEkran.getSinemaButon()){
            AdminSinemaEkran adminSinemaEkran = new AdminSinemaEkran();
            adminAnaEkran.dispose();
        }
    }
    
}
