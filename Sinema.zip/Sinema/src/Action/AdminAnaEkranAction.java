package Action;

import GUI.AdminAnaEkran;
import GUI.AdminSeansEkran;
import GUI.AdminIzleyiciEkran;
import GUI.AdminBiletEkran;
import GUI.AdminFilmEkran;
import GUI.GirisEkrani;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AdminAnaEkranAction implements ActionListener {

    AdminAnaEkran adminAnaEkran;
    AdminFilmEkran adminFilmEkran;
    AdminSeansEkran adminSeansEkran;
    AdminBiletEkran adminBiletEkran;
    AdminIzleyiciEkran adminIzleyiciEkran;
    GirisEkrani girisEkrani;

    public AdminAnaEkranAction(AdminAnaEkran adminAnaEkran) {
        this.adminAnaEkran = adminAnaEkran;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == adminAnaEkran.getFilmButton()) {
            adminFilmEkran = new AdminFilmEkran();
            adminAnaEkran.dispose();
        }
        if (e.getSource() == adminAnaEkran.getSeansButton()) {
            adminSeansEkran = new AdminSeansEkran();
            adminAnaEkran.dispose();
        }
        if (e.getSource() == adminAnaEkran.getBiletButon()) {
            adminBiletEkran = new AdminBiletEkran();
            adminAnaEkran.dispose();
        }
        if (e.getSource() == adminAnaEkran.getIzleyiciButton()) {
            adminIzleyiciEkran = new AdminIzleyiciEkran();
            adminAnaEkran.dispose();
        }
        if (e.getSource() == adminAnaEkran.getGeriButon()) {
            girisEkrani = new GirisEkrani();
            adminAnaEkran.dispose();
        }

    }

}
