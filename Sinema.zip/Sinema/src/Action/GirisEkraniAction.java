package Action;

import GUI.AdminAnaEkran;
import GUI.GirisEkrani;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GirisEkraniAction implements ActionListener{
    GirisEkrani girisEkrani;

    public GirisEkraniAction(GirisEkrani girisEkrani) {
        this.girisEkrani = girisEkrani;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == girisEkrani.getButton1()){
            AdminAnaEkran adminAnaEkran = new AdminAnaEkran();
            girisEkrani.dispose();
        }
    }
    
}
