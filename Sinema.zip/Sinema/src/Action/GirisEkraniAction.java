package Action;

import Controller.KullaniciController;
import DAO.KullanıcılarDao;
import Entity.Kullanici;
import GUI.AdminAnaEkran;
import GUI.GirisEkrani;
import GUI.KaydolEkrani;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class GirisEkraniAction implements ActionListener {

    GirisEkrani girisEkrani;

    public GirisEkraniAction(GirisEkrani girisEkrani) {
        this.girisEkrani = girisEkrani;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == girisEkrani.getButton1()) {
            String kullaniciAdi = girisEkrani.getTextField().getText();
            String sifre = girisEkrani.getPasswordField().getText();
            KullaniciController kullaniciController = new KullaniciController();
            try {
                if (kullaniciController.Kontrol(kullaniciAdi, sifre)) {
                    AdminAnaEkran adminAnaEkran = new AdminAnaEkran();
                    girisEkrani.dispose();
                }
                else{
                    JOptionPane.showMessageDialog(null, "Giriş Bilgileri hatalıdır.");
                }
            } 
            catch (IOException ex) {
                Logger.getLogger(GirisEkraniAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (e.getSource() == girisEkrani.getButton2()) {

            KaydolEkrani kaydolEkrani = new KaydolEkrani();
            girisEkrani.dispose();
        }
    }

}
