package Action;

import Controller.KullaniciController;
import GUI.AnaEkran;
import GUI.GirisEkrani;
import GUI.KaydolEkrani;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class KaydolEkraniAction implements ActionListener {

    KaydolEkrani kaydolEkrani;
    GirisEkrani girisEkrani;

    public KaydolEkraniAction(KaydolEkrani kaydolEkrani) {
        this.kaydolEkrani = kaydolEkrani;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == kaydolEkrani.getKaydolButonu()) {
            String adSoyad = kaydolEkrani.getAdSoyadTextField().getText();
            char cinsiyet;
            if (kaydolEkrani.getMaleButton().isSelected()) {
                cinsiyet = 'E';
            } 
            else {
                if (kaydolEkrani.getFemaleButton().isSelected()) {
                    cinsiyet = 'K';
                } 
                else {
                    cinsiyet = 'N';
                }
            }
            String kullaniciAdi = kaydolEkrani.getKullaniciAdiTextField().getText();
            String telefonNoString = kaydolEkrani.getTelefonnoTextField().getText();
            
            String sifre = kaydolEkrani.getSifreTextField().getText();
            KullaniciController kullaniciController = new KullaniciController();
            try {
                kullaniciController.Olustur(adSoyad, cinsiyet, telefonNoString, kullaniciAdi, sifre);
            } 
            catch (IOException ex) {
                Logger.getLogger(KaydolEkraniAction.class.getName()).log(Level.SEVERE, null, ex);
            }
            kaydolEkrani.dispose();
            girisEkrani = new GirisEkrani();
            JOptionPane.showMessageDialog(null, "Kayıt başarılı giriş yapınız.");
        }
        if(e.getSource() == kaydolEkrani.getGeriButon()){
            girisEkrani = new GirisEkrani();
            kaydolEkrani.dispose();
        }
    }

}
