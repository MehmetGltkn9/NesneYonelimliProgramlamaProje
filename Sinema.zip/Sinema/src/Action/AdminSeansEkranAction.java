package Action;

import Controller.FilmController;
import Controller.SeansController;
import GUI.AdminAnaEkran;
import GUI.AdminSeansEkran;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.JOptionPane;

public class AdminSeansEkranAction implements ActionListener{
    AdminSeansEkran adminSeansEkran;
    AdminAnaEkran adminAnaEkran;
    public AdminSeansEkranAction(AdminSeansEkran adminSeansEkran) {
        this.adminSeansEkran = adminSeansEkran;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == adminSeansEkran.getGeriButon()){
            adminAnaEkran = new AdminAnaEkran();
            adminSeansEkran.dispose();
        }
        if (e.getSource() == adminSeansEkran.getEkleButon()) {
            String film = adminSeansEkran.getFilmTextField().getText();
            String salon = adminSeansEkran.getSalonTextField().getText();
            String tarihSaat = adminSeansEkran.getTarihSaatTextField().getText();
            String doluluk = adminSeansEkran.getDolulukTextField().getText();
            SeansController seansController = new SeansController();
            try {
                seansController.Olustur(film, salon, tarihSaat, doluluk);
                adminSeansEkran.TabloGuncelle();
            } catch (IOException ex) {

            }
            JOptionPane.showMessageDialog(null, "Kayıt başarılı");
        }
        if(e.getSource() == adminSeansEkran.getSilButon()){
            int selectedRow = adminSeansEkran.getTablo().getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Lütfen silmek istediğiniz satırı seçin!!");
            }
            else{
                SeansController seansController = new SeansController();
                seansController.Sil(selectedRow);
                adminSeansEkran.getDTM().removeRow(selectedRow);
            }
        }
    }
    
}
