package Action;

import Controller.IzleyiciController;
import GUI.AdminAnaEkran;
import GUI.AdminIzleyiciEkran;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class AdminIzleyiciEkranAction implements ActionListener {

    AdminIzleyiciEkran adminIzleyiciEkran;
    AdminAnaEkran adminAnaEkran;

    public AdminIzleyiciEkranAction(AdminIzleyiciEkran adminIzleyiciEkran) {
        this.adminIzleyiciEkran = adminIzleyiciEkran;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == adminIzleyiciEkran.getGeriButon()) {
            adminAnaEkran = new AdminAnaEkran();
            adminIzleyiciEkran.dispose();
        }
        if (e.getSource() == adminIzleyiciEkran.getEkleButon()) {
            String adSoyad = adminIzleyiciEkran.getAdSoyadTextField().getText();
            String sifre = adminIzleyiciEkran.getCinsiyetTextField().getText();
            char cinsiyet;
            if (adminIzleyiciEkran.getMaleButton().isSelected()) {
                cinsiyet = 'E';
            } 
            else {
                if (adminIzleyiciEkran.getFemaleButton().isSelected()) {
                    cinsiyet = 'K';
                } 
                else {
                    cinsiyet = 'N';
                }
            }
            String telefonNo = adminIzleyiciEkran.getTelefonNoTextField().getText();
            String kullaniciAdi = adminIzleyiciEkran.getKullaniciAdiTextField().getText();
            IzleyiciController izleyiciController = new IzleyiciController();
            izleyiciController.Olustur(adSoyad, cinsiyet,telefonNo, kullaniciAdi,sifre);
            adminIzleyiciEkran.TabloGuncelle();
        }
        if(e.getSource() == adminIzleyiciEkran.getSilButon()){
            int selectedRow = adminIzleyiciEkran.getTablo().getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Lütfen silmek istediğiniz satırı seçin!!");
            }
            else{
                IzleyiciController izleyiciController = new IzleyiciController();
                izleyiciController.Sil(selectedRow);
                adminIzleyiciEkran.getDTM().removeRow(selectedRow);
            }
        }
        
    }

}
