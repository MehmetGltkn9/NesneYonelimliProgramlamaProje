package Action;

import Controller.BiletController;
import GUI.AdminAnaEkran;
import GUI.AdminBiletEkran;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class AdminBiletEkranAction implements ActionListener {

    AdminBiletEkran adminBiletEkran;
    AdminAnaEkran adminAnaEkran;
    JButton selectedButton = null;

    public AdminBiletEkranAction(AdminBiletEkran adminBiletEkran) {
        this.adminBiletEkran = adminBiletEkran;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == adminBiletEkran.getGeriButon()) {
            adminAnaEkran = new AdminAnaEkran();
            adminBiletEkran.dispose();
        }
        if (e.getSource() == adminBiletEkran.getSalonlar()) {
            int salonNo = adminBiletEkran.getSalonlar().getSelectedIndex();
            BiletController BC = new BiletController();
            BC.SalonDegistir(salonNo + 1);

        }
        if (e.getSource() == adminBiletEkran.getBiletAl()) {
            BiletController Bc = new BiletController();
            int j = adminBiletEkran.getSalonlar().getSelectedIndex();
            if(Bc.getDoluMu(j)){
                JOptionPane.showMessageDialog(null, "Koltuk zaten dolu");
            }
            else{
                JOptionPane.showMessageDialog(null, "Bilet alındı");
                JButton button = (JButton) adminBiletEkran.getPanel1().getComponent(j);
                button.setBackground(new Color(255,0,0));
                Bc.setDoluMu(j);
            }
        }
        for (int i = 0; i < 42; i++) {
            if (e.getSource() == adminBiletEkran.getPanel1().getComponent(i)) {
                JButton button = (JButton) adminBiletEkran.getPanel1().getComponent(i);
                button.setBorderPainted(true);
            }
        }
        if (e.getSource() == adminBiletEkran.getBiletIptal()) {
            BiletController Bc = new BiletController();
            int j = adminBiletEkran.getSalonlar().getSelectedIndex();
            if(!Bc.getDoluMu(j)){
                JOptionPane.showMessageDialog(null, "Koltuk zaten Boş");
            }
            else{
                JOptionPane.showMessageDialog(null, "Bilet iptal edildi");
                JButton button = (JButton) adminBiletEkran.getPanel1().getComponent(j);
                button.setBackground(new Color(204,153,255));
                Bc.setBos(j);
            }
        }

    }

}
