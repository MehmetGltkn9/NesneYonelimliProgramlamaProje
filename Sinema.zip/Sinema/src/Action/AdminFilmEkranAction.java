package Action;

import Controller.FilmController;
import GUI.AdminAnaEkran;
import GUI.AdminFilmEkran;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import javax.swing.JOptionPane;

public class AdminFilmEkranAction implements ActionListener {

    AdminFilmEkran adminSinemaEkran;
    AdminAnaEkran adminAnaEkran;

    public AdminFilmEkranAction(AdminFilmEkran adminSinemaEkran) {
        this.adminSinemaEkran = adminSinemaEkran;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == adminSinemaEkran.getGeriButon()) {
            adminAnaEkran = new AdminAnaEkran();
            adminSinemaEkran.dispose();
        }
        if (e.getSource() == adminSinemaEkran.getEkleButon()) {
            String filmAdi = adminSinemaEkran.getFilmAdiTextField().getText();
            String filmYonetmen = adminSinemaEkran.getFilmYonetmenTextField().getText();
            int filmSuresi = Integer.parseInt(adminSinemaEkran.getFilmSuresiTextField().getText());
            String filmTuru = adminSinemaEkran.getFilmTuruTextField().getText();
            FilmController kullaniciController = new FilmController();
            kullaniciController.Olustur(filmAdi, filmYonetmen, filmSuresi, filmTuru);
            adminSinemaEkran.TabloGuncelle();
            JOptionPane.showMessageDialog(null, "Kayıt başarılı");
        }
        if (e.getSource() == adminSinemaEkran.getSilButon()) {
            int selectedRow = adminSinemaEkran.getJtable().getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Lütfen silmek istediğiniz satırı seçin!!");
            }
            else{
                FilmController kullaniciController = new FilmController();
                kullaniciController.Sil(selectedRow);
                adminSinemaEkran.getDTM().removeRow(selectedRow);
            }
        }
    }

}
