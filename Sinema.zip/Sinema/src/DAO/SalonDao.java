package DAO;

public class SalonDao {
    
}
