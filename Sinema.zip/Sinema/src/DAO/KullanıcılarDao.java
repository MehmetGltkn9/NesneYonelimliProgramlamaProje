package DAO;

import Entity.Kullanici;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class KullanıcılarDao extends AbstractDao {

    List<Kullanici> kullanicilar;

    public KullanıcılarDao() {
        kullanicilar = new ArrayList<>();
    }

    @Override
    public void Olustur(Object object) throws IOException {
        try {
            FileWriter FR = new FileWriter("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Kullanıcılar.txt", true);
            try(BufferedWriter BR = new BufferedWriter(FR)){
               BR.append(object + "\n");
            }       
        } 
        catch (Exception e) {
            
        }
    }

    @Override
    public AbstractDao Guncelle() {
        return null;
    }

    @Override
    public void Al() {

    }

    public boolean Kontrol(Kullanici kullanici) throws FileNotFoundException, IOException {
        FileReader FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Kullanıcılar.txt");
        BufferedReader BR = new BufferedReader(FR);
        String line;
        while ((line = BR.readLine()) != null) {
            String[] parts = line.split(";");
            String kullaniciAdi = parts[3];
            String sifre = parts[4];
            if (kullaniciAdi.equals(kullanici.getKullaniciAdi()) && sifre.equals(kullanici.getSifre())) {
                BR.close();
                FR.close();
                return true;
            }
        }

        BR.close();
        FR.close();
        return false;

    }

    @Override
    public void Sil(int selectedRow) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
