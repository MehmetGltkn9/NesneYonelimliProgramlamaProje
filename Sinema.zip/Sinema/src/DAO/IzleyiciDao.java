package DAO;

import Entity.Izleyici;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class IzleyiciDao {

    List<Izleyici> izleyiciler = new ArrayList<>();

    public List<Izleyici> ListeyiAl() {
        FileReader FR;
        try {

            FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Izleyici.txt");
            BufferedReader BR = new BufferedReader(FR);

            String line = BR.readLine();
            while (line != null) {
                String veri[] = line.split(";");

                Izleyici f = new Izleyici(veri[0], veri[1].charAt(0), veri[2], veri[3]);
                this.izleyiciler.add(f);
                line = BR.readLine();

            }
            return izleyiciler;
        } catch (IOException ex) {
            Logger.getLogger(IzleyiciDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public void Olustur(Object object) {
        try {
            FileWriter FR = new FileWriter("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Izleyici.txt", true);
            try ( BufferedWriter BR = new BufferedWriter(FR)) {
                BR.append(object.toString() + "\n");
            }
        } catch (Exception e) {

        }
    }

    public void Sil(int selectedRow) {
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Izleyici.txt"));

            ArrayList<String> lines = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            reader.close();

            lines.remove(selectedRow);

            BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Izleyici.txt"));
            for (String newLine : lines) {
                writer.write(newLine);
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
