package DAO;

import Entity.Salon;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BiletDao {

    public void SalonDegistir(int i) {
        FileReader FR;
        try {
            Salon salon = new Salon();
            salon.setSalonNo(i);

            switch (i) {
                case 1:
                    FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Salon1.txt");
                    break;
                case 2:
                    FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Salon2.txt");
                    break;
                case 3:
                    FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Salon3.txt");
                    break;
                case 4:
                    FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Salon4.txt");
                    break;
                case 5:
                    FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Salon5.txt");
                    break;
                case 6:
                    FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Salon6.txt");
                    break;
                case 7:
                    FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Salon7.txt");
                    break;
                case 8:
                    FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Salon8.txt");
                    break;
                case 9:
                    FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Salon9.txt");
                    break;
                case 10:
                    FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Salon10.txt");
                    break;
                default:
                    FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Salon1.txt");
                    break;
            }
            BufferedReader BR = new BufferedReader(FR);
            String line = BR.readLine();
            while (line != null) {
                String veri[] = line.split(";");
                if (Integer.parseInt(veri[0]) == i) {
                    salon.setSalonTuru(veri[1]);
                    salon.setIzleyiciKapasitesi(42);
                    break;
                }
            }

        } catch (IOException ex) {

        }

    }

    public boolean getDoluMu(int i) {
        try {
            FileReader FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Salon.txt");
            BufferedReader BR = new BufferedReader(FR);
            String line;
            while ((line = BR.readLine()) != null) {
                String[] parts = line.split(";");
                String indeks = parts[0];
                String indeks2 = String.valueOf(i);
                if (indeks == null ? indeks2 == null : indeks.equals(indeks2)) {

                    indeks = parts[1];
                    if ("1".equals(indeks)) {
                        BR.close();
                        FR.close();
                        return true;
                    }
                }
            }

            BR.close();
            FR.close();
            return false;
        } catch (IOException ex) {
            Logger.getLogger(BiletDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public void setDoluMu(int i) throws FileNotFoundException {
        File file = new File("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Salon.txt");
        Scanner sc = new Scanner(file);

        // Dosya içeriğini bir String dizisine alın
        String[] lines = new String[100]; // Burada 100 satır için yer ayırdık, ancak gerçek dosya satır sayısını kullanabilirsiniz
        int k = 0;
        while (sc.hasNextLine()) {
            lines[k++] = sc.nextLine();
        }
        sc.close();

        // Belirli bir satırı değiştirin
        int lineNumber = i; // Değiştirilecek satır numarası
        String newLine = i+";"+"1"; // Değiştirilecek yeni satır
        lines[lineNumber - 1] = newLine; // Satır numarası 1'den başlar, dizi indeksleri 0'dan başlar

        // Değiştirilen satırları dosyaya yazın
        PrintWriter pw = new PrintWriter(file);
        for (String line : lines) {
            pw.println(line);
        }
        pw.close();
    }

    public void setBos(int i) throws FileNotFoundException {
        File file = new File("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Salon.txt");
        Scanner sc = new Scanner(file);

        // Dosya içeriğini bir String dizisine alın
        String[] lines = new String[100]; // Burada 100 satır için yer ayırdık, ancak gerçek dosya satır sayısını kullanabilirsiniz
        int k = 0;
        while (sc.hasNextLine()) {
            lines[k++] = sc.nextLine();
        }
        sc.close();

        // Belirli bir satırı değiştirin
        int lineNumber = i; // Değiştirilecek satır numarası
        String newLine = i+";"+"0"; // Değiştirilecek yeni satır
        lines[lineNumber - 1] = newLine; // Satır numarası 1'den başlar, dizi indeksleri 0'dan başlar

        // Değiştirilen satırları dosyaya yazın
        PrintWriter pw = new PrintWriter(file);
        for (String line : lines) {
            pw.println(line);
        }
        pw.close();
    }
}
