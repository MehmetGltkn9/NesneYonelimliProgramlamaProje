package DAO;

import Entity.Film;
import Entity.Salon;
import Entity.Seans;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SeansDao extends AbstractDao {

    private List<Seans> seanslar = new ArrayList<>();

    public List<Seans> ListeyiAl() {
        FileReader FR;
        try {
            FR = new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Seans.txt");
            BufferedReader BR = new BufferedReader(FR);
            String line = BR.readLine();
            while (line != null) {
                String veri[] = line.split(";");
                Seans f = new Seans(new Film(veri[0]), new Salon(Integer.parseInt(veri[1])), veri[2], Integer.parseInt(veri[3]));
                this.seanslar.add(f);
                line = BR.readLine();
            }
            return seanslar;
        } catch (IOException ex) {
            Logger.getLogger(SeansDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    @Override
    public void Olustur(Object seans){
        try {
            FileWriter FR = new FileWriter("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Seans.txt", true);
            try ( BufferedWriter BR = new BufferedWriter(FR)) {
                BR.append(seans.toString() + "\n");
            }
        } catch (Exception e) {

        }
    }

    @Override
    public AbstractDao Guncelle() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void Sil(int selectedRow) {
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Seans.txt"));

            ArrayList<String> lines = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            reader.close();

            lines.remove(selectedRow);

            BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\mehme\\OneDrive\\Belgeler\\NetBeansProjects\\Sinema\\src\\Data\\Seans.txt"));
            for (String newLine : lines) {
                writer.write(newLine);
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void Al() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
