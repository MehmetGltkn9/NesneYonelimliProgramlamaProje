package GUI;

import Action.AdminFilmEkranAction;
import Controller.FilmController;
import DAO.FilmDao;
import Entity.Film;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.table.DefaultTableModel;

public class AdminFilmEkran extends JFrame {

    private JPanel anaEkranPanel;
    private JTable Jtable;
    private JScrollPane scrollPane;
    private JLabel filmAdiLabel;
    private JLabel filmSuresiLabel;
    private JLabel filmTuruLabel;
    private JLabel filmYonetmenLabel;
    private JButton GeriButon;
    private JButton EkleButon;
    private JButton SilButon;
    private JTextField filmAdiTextField;
    private JTextField filmSuresiTextField;
    private JTextField filmTuruTextField;
    private JTextField filmYonetmenTextField;
    private DefaultTableModel DTM;
    private Object[] tabloVeri;
    private FilmController FC;

    public AdminFilmEkran(){
        TabloOlustur();
        Olustur();
    }

    private void Olustur() {
        add(PanelEkle());
        setBounds(500, 200, 1000, 600);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    private void TabloOlustur(){
        FC = new FilmController();
        DTM = new DefaultTableModel();
        Object[] tabloObje = new Object[4];

        tabloObje[0] = "Film Adı";
        tabloObje[1] = "Yönetmen";
        tabloObje[2] = "Film Süresi";
        tabloObje[3] = "Film Türü";

        DTM.setColumnIdentifiers(tabloObje);
        tabloVeri = new Object[4];

        List<Film> filmler = FC.ListeyiAl();
        for (int i = 0; i < filmler.size(); i++) {
            tabloVeri[0] = filmler.get(i).getFilmAdi();
            tabloVeri[1] = filmler.get(i).getYonetmen();
            tabloVeri[2] = filmler.get(i).getFilmSuresi();
            tabloVeri[3] = filmler.get(i).getFilmTuru();
            DTM.addRow(tabloVeri);
        }

        PanelEkle();
    }

    public void TabloGuncelle(){
        List<Film> filmler = FC.ListeyiAl();
        DTM.setRowCount(0);
        for (int i = 0; i < filmler.size(); i++) {
            tabloVeri[0] = filmler.get(i).getFilmAdi();
            tabloVeri[1] = filmler.get(i).getYonetmen();
            tabloVeri[2] = filmler.get(i).getFilmSuresi();
            tabloVeri[3] = filmler.get(i).getFilmTuru();
            DTM.addRow(tabloVeri);
        }
        PanelEkle();
    }

    public JPanel PanelEkle() {
        anaEkranPanel = getAnaEkranPanel();
        anaEkranPanel.setLayout(null);
        anaEkranPanel.add(getScrollPane());
        anaEkranPanel.add(getEkleButon());
        anaEkranPanel.add(getGeriButon());
        anaEkranPanel.add(getSilButon());
        anaEkranPanel.add(getFilmAdiLabel());
        anaEkranPanel.add(getFilmAdiTextField());
        anaEkranPanel.add(getFilmSuresiLabel());
        anaEkranPanel.add(getFilmSuresiTextField());
        anaEkranPanel.add(getFilmTuruLabel());
        anaEkranPanel.add(getFilmTuruTextField());
        anaEkranPanel.add(getFilmYonetmenLabel());
        anaEkranPanel.add(getFilmYonetmenTextField());
        anaEkranPanel.setBackground(Color.LIGHT_GRAY);
        return anaEkranPanel;
    }

    public JPanel getAnaEkranPanel() {
        if (anaEkranPanel == null) {
            anaEkranPanel = new JPanel();
            anaEkranPanel.setBounds(250, 300, 900, 600);
        }
        return anaEkranPanel;
    }

    public void setAnaEkranPanel(JPanel anaEkranPanel) {
        this.anaEkranPanel = anaEkranPanel;
    }

    public JTable getJtable() {
        if (Jtable == null) {
            this.Jtable = new JTable();
            Jtable.setBounds(40, 40, 400, 500);
            Jtable.setBackground(new Color(204,153,255));
            Jtable.setModel(DTM);
        }
        return Jtable;
    }

    public void setJtable(JTable Jtable) {
        this.Jtable = Jtable;
    }

    public JButton getGeriButon() {
        if (GeriButon == null) {
            GeriButon = new JButton("<--Geri--");
            GeriButon.setBounds(850, 20, 100, 40);
            GeriButon.addActionListener(new AdminFilmEkranAction(this));
            GeriButon.setBackground(Color.white);
        }
        return GeriButon;
    }

    public void setGeriButon(JButton GeriButon) {
        this.GeriButon = GeriButon;
    }

    public JButton getEkleButon() {
        if (EkleButon == null) {
            EkleButon = new JButton("Ekle");
            EkleButon.setBounds(550, 370, 100, 40);
            EkleButon.addActionListener(new AdminFilmEkranAction(this));
            EkleButon.setBackground(Color.GRAY);
        }
        return EkleButon;
    }

    public void setEkleButon(JButton EkleButon) {
        this.EkleButon = EkleButon;
    }

    public JButton getSilButon() {
        if (SilButon == null) {
            SilButon = new JButton("Sil");
            SilButon.setBounds(760, 370, 100, 40);
            SilButon.addActionListener(new AdminFilmEkranAction(this));
            SilButon.setBackground(Color.GRAY);
        }
        return SilButon;
    }

    public void setSilButon(JButton SilButon) {
        this.SilButon = SilButon;
    }

    public JScrollPane getScrollPane() {
        if (scrollPane == null) {
            scrollPane = new JScrollPane();
            scrollPane.setBounds(40, 40, 400, 500);
            scrollPane.setViewportView(getJtable());
        }
        return scrollPane;
    }

    public void setScrollPane(JScrollPane scrollPane) {
        this.scrollPane = scrollPane;
    }

    public JLabel getFilmAdiLabel() {
        if (filmAdiLabel == null) {
            filmAdiLabel = new JLabel("FİLM ADI");
            filmAdiLabel.setBounds(550, 60, 200, 100);
            filmAdiLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        }
        return filmAdiLabel;
    }

    public void setFilmAdiLabel(JLabel filmAdiLabel) {
        this.filmAdiLabel = filmAdiLabel;
    }

    public JLabel getFilmSuresiLabel() {
        if (filmSuresiLabel == null) {
            filmSuresiLabel = new JLabel("FİLM SÜRESİ");
            filmSuresiLabel.setBounds(750, 60, 200, 100);
            filmSuresiLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        }
        return filmSuresiLabel;
    }

    public void setFilmSuresiLabel(JLabel filmSuresiLabel) {
        this.filmSuresiLabel = filmSuresiLabel;
    }

    public JLabel getFilmTuruLabel() {
        if (filmTuruLabel == null) {
            filmTuruLabel = new JLabel("FİLM TÜRÜ");
            filmTuruLabel.setBounds(540, 200, 200, 100);
            filmTuruLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        }

        return filmTuruLabel;
    }

    public void setFilmTuruLabel(JLabel filmTuruLabel) {
        this.filmTuruLabel = filmTuruLabel;
    }

    public JLabel getFilmYonetmenLabel() {
        if (filmYonetmenLabel == null) {
            filmYonetmenLabel = new JLabel("FİLM YÖNETMEN");
            filmYonetmenLabel.setBounds(725, 200, 300, 100);
            filmYonetmenLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        }
        return filmYonetmenLabel;
    }

    public void setFilmYonetmenLabel(JLabel filmYonetmenLabel) {
        this.filmYonetmenLabel = filmYonetmenLabel;
    }

    public JTextField getFilmAdiTextField() {
        if (filmAdiTextField == null) {
            filmAdiTextField = new JTextField();
            filmAdiTextField.setBounds(525, 150, 150, 35);
        }
        return filmAdiTextField;
    }

    public void setFilmAdiTextField(JTextField filmAdiTextField) {
        this.filmAdiTextField = filmAdiTextField;
    }

    public JTextField getFilmSuresiTextField() {
        if (filmSuresiTextField == null) {
            filmSuresiTextField = new JTextField();
            filmSuresiTextField.setBounds(740, 150, 150, 35);
        }
        return filmSuresiTextField;
    }

    public void setFilmSuresiTextField(JTextField filmSuresiTextField) {
        this.filmSuresiTextField = filmSuresiTextField;
    }

    public JTextField getFilmTuruTextField() {
        if (filmTuruTextField == null) {
            filmTuruTextField = new JTextField();
            filmTuruTextField.setBounds(525, 290, 150, 35);
        }
        return filmTuruTextField;
    }

    public void setFilmTuruTextField(JTextField filmTuruTextField) {
        this.filmTuruTextField = filmTuruTextField;
    }

    public JTextField getFilmYonetmenTextField() {
        if (filmYonetmenTextField == null) {
            filmYonetmenTextField = new JTextField();
            filmYonetmenTextField.setBounds(740, 290, 150, 35);
        }
        return filmYonetmenTextField;
    }

    public void setFilmYonetmenTextField(JTextField filmYonetmenTextField) {
        this.filmYonetmenTextField = filmYonetmenTextField;
    }

    public DefaultTableModel getDTM() {
        return DTM;
    }

    public void setDTM(DefaultTableModel DTM) {
        this.DTM = DTM;
    }

    public FilmController getFC() {
        return FC;
    }

    public void setFC(FilmController FC) {
        this.FC = FC;
    }
    
    
}
