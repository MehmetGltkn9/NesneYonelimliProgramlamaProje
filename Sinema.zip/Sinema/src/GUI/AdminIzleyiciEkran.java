package GUI;

import Action.AdminIzleyiciEkranAction;
import Controller.IzleyiciController;
import Controller.SeansController;
import Entity.Izleyici;
import Entity.Seans;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.table.DefaultTableModel;

public class AdminIzleyiciEkran extends JFrame {

    private JPanel izleyiciEkranPanel;
    private JTable tablo;
    private JScrollPane scrollPano;
    private JLabel adSoyad;
    private JLabel telefonNo;
    private JLabel kullaniciAdi;
    private JLabel adSoyadLabel;
    private JLabel telefonNoLabel;
    private JLabel kullaniciAdiLabel;
    private JLabel cinsiyetLabel;
    private JButton GeriButon;
    private JButton EkleButon;
    private JButton SilButon;
    private JTextField adSoyadTextField;
    private JTextField telefonNoTextField;
    private JTextField kullaniciAdiTextField;
    private JTextField cinsiyetTextField;
    private DefaultTableModel DTM;
    private Object[] tabloVeri;
    private IzleyiciController IC;
    private ButtonGroup cinsiyet;
    private JRadioButton maleButton;
    private JRadioButton femaleButton;

    public AdminIzleyiciEkran(){
        TabloOlustur();
        Olustur();
    }

    private void Olustur() {
        add(PanelEkle());
        setBounds(500, 200, 1000, 600);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    private void TabloOlustur(){
        IC = new IzleyiciController();
        DTM = new DefaultTableModel();
        Object[] tabloObje = new Object[4];

        tabloObje[0] = "Ad-Soyad";
        tabloObje[1] = "Telefon No";
        tabloObje[2] = "Kullanıcı Adı";
        tabloObje[3] = "Cinsiyet";

        DTM.setColumnIdentifiers(tabloObje);
        tabloVeri = new Object[4];

        List<Izleyici> izleyiciler = IC.ListeyiAl();
        for (int i = 0; i < izleyiciler.size(); i++) {
            tabloVeri[0] = izleyiciler.get(i).getAdSoyad();
            tabloVeri[1] = izleyiciler.get(i).getTelefonNo();
            tabloVeri[2] = izleyiciler.get(i).getKullaniciAdi();
            tabloVeri[3] = izleyiciler.get(i).getCinsiyet();
            DTM.addRow(tabloVeri);
        }

        PanelEkle();
    }

    public JPanel PanelEkle() {
        izleyiciEkranPanel = getIzleyiciEkranPanel();
        izleyiciEkranPanel.setLayout(null);
        izleyiciEkranPanel.add(getScrollPano());
        izleyiciEkranPanel.add(getEkleButon());
        izleyiciEkranPanel.add(getGeriButon());
        izleyiciEkranPanel.add(getSilButon());
        izleyiciEkranPanel.add(getAdSoyadLabel());
        izleyiciEkranPanel.add(getAdSoyadTextField());
        izleyiciEkranPanel.add(getTelefonNoLabel());
        izleyiciEkranPanel.add(getTelefonNoTextField());
        izleyiciEkranPanel.add(getKullaniciAdiLabel());
        izleyiciEkranPanel.add(getKullaniciAdiTextField());
        izleyiciEkranPanel.add(getCinsiyetLabel());
        izleyiciEkranPanel.add(getCinsiyetTextField());
        
        cinsiyet = new ButtonGroup();
        cinsiyet.add(getMaleButton());
        cinsiyet.add(getFemaleButton());
        izleyiciEkranPanel.add(getMaleButton());
        izleyiciEkranPanel.add(getFemaleButton());
        izleyiciEkranPanel.setBackground(Color.LIGHT_GRAY);
        return izleyiciEkranPanel;
    }

    public void TabloGuncelle(){
        List<Izleyici> izleyiciler = IC.ListeyiAl();
        DTM.setRowCount(0);
        for (int i = 0; i < izleyiciler.size(); i++) {
            tabloVeri[0] = izleyiciler.get(i).getAdSoyad();
            tabloVeri[1] = izleyiciler.get(i).getTelefonNo();
            tabloVeri[2] = izleyiciler.get(i).getKullaniciAdi();
            tabloVeri[3] = izleyiciler.get(i).getCinsiyet();
            DTM.addRow(tabloVeri);
        }
        PanelEkle();
    }

    public JPanel getIzleyiciEkranPanel() {
        if (izleyiciEkranPanel == null) {
            izleyiciEkranPanel = new JPanel();
            izleyiciEkranPanel.setBounds(250, 300, 900, 600);
        }
        return izleyiciEkranPanel;
    }

    public void setIzleyiciEkranPanel(JPanel izleyiciEkranPanel) {
        this.izleyiciEkranPanel = izleyiciEkranPanel;
    }

    public JTable getTablo() {
        if (tablo == null) {
            this.tablo = new JTable();
            tablo.setBounds(40, 40, 400, 500);
            tablo.setBackground(new Color(204, 153, 255));
            tablo.setModel(DTM);
        }
        return tablo;
    }

    public void setTablo(JTable tablo) {
        this.tablo = tablo;
    }

    public JButton getGeriButon() {
        if (GeriButon == null) {
            GeriButon = new JButton("<--Geri--");
            GeriButon.setBounds(850, 20, 100, 40);
            GeriButon.setBackground(Color.white);
            GeriButon.addActionListener(new AdminIzleyiciEkranAction(this));
        }
        return GeriButon;
    }

    public void setGeriButon(JButton GeriButon) {
        this.GeriButon = GeriButon;
    }

    public JButton getEkleButon() {
        if (EkleButon == null) {
            EkleButon = new JButton("Ekle");
            EkleButon.setBounds(550, 420, 100, 40);
            EkleButon.setBackground(Color.GRAY);
            EkleButon.addActionListener(new AdminIzleyiciEkranAction(this));
            EkleButon.setBackground(Color.GRAY);
        }
        return EkleButon;
    }

    public void setEkleButon(JButton EkleButon) {
        this.EkleButon = EkleButon;
    }

    public JButton getSilButon() {
        if (SilButon == null) {
            SilButon = new JButton("Sil");
            SilButon.setBounds(760, 420, 100, 40);
            SilButon.addActionListener(new AdminIzleyiciEkranAction(this));
            SilButon.setBackground(Color.GRAY);
        }
        return SilButon;
    }

    public void setSilButon(JButton SilButon) {
        this.SilButon = SilButon;
    }

    public JScrollPane getScrollPano() {
        if (scrollPano == null) {
            scrollPano = new JScrollPane();
            scrollPano.setBounds(40, 40, 400, 500);
            scrollPano.setViewportView(getTablo());
        }
        return scrollPano;
    }

    public void setScrollPano(JScrollPane scrollPano) {
        this.scrollPano = scrollPano;
    }

    public JLabel getAdSoyadLabel() {
        if (adSoyadLabel == null) {
            adSoyad = new JLabel("AD SOYAD");
            adSoyad.setBounds(550, 60, 200, 100);
            adSoyad.setFont(new Font("Times New Roman", Font.BOLD, 20));
        }
        return adSoyad;
    }

    public void setAdSoyadLabel(JLabel adSoyadLabel) {
        this.adSoyadLabel = adSoyadLabel;
    }

    public JLabel getTelefonNoLabel() {
        if (telefonNoLabel == null) {
            telefonNo = new JLabel("TELEFON NO");
            telefonNo.setBounds(750, 60, 200, 100);
            telefonNo.setFont(new Font("Times New Roman", Font.BOLD, 20));
        }
        return telefonNo;
    }

    public void setTelefonNoLabel(JLabel telefonNo) {
        this.telefonNo = telefonNo;
    }

    public JLabel getKullaniciAdiLabel() {
        if (kullaniciAdiLabel == null) {
            kullaniciAdi = new JLabel("KULLANICI ADI");
            kullaniciAdi.setBounds(525, 200, 200, 100);
            kullaniciAdi.setFont(new Font("Times New Roman", Font.BOLD, 20));
        }

        return kullaniciAdi;
    }

    public void setKullaniciAdiLabel(JLabel kullaniciAdi) {
        this.kullaniciAdi = kullaniciAdi;
    }

    public JLabel getCinsiyetLabel() {
        if (cinsiyetLabel == null) {
            cinsiyetLabel = new JLabel("SİFRE");
            cinsiyetLabel.setBounds(785, 200, 300, 100);
            cinsiyetLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        }
        return cinsiyetLabel;
    }

    public void setCinsiyetLabel(JLabel cinsiyetLabel) {
        this.cinsiyetLabel = cinsiyetLabel;
    }

    public JTextField getAdSoyadTextField() {
        if (adSoyadTextField == null) {
            adSoyadTextField = new JTextField();
            adSoyadTextField.setBounds(525, 150, 150, 35);
        }
        return adSoyadTextField;
    }

    public void setAdSoyadTextField(JTextField adSoyadTextField) {
        this.adSoyadTextField = adSoyadTextField;
    }

    public JTextField getTelefonNoTextField() {
        if (telefonNoTextField == null) {
            telefonNoTextField = new JTextField();
            telefonNoTextField.setBounds(740, 150, 150, 35);
        }
        return telefonNoTextField;
    }

    public void setTelefonNoTextField(JTextField telefonNoTextField) {
        this.telefonNoTextField = telefonNoTextField;
    }

    public JTextField getKullaniciAdiTextField() {
        if (kullaniciAdiTextField == null) {
            kullaniciAdiTextField = new JTextField();
            kullaniciAdiTextField.setBounds(525, 290, 150, 35);
        }
        return kullaniciAdiTextField;
    }

    public void setKullaniciAdiTextField(JTextField kullaniciAdiTextField) {
        this.kullaniciAdiTextField = kullaniciAdiTextField;
    }

    public JTextField getCinsiyetTextField() {
        if (cinsiyetTextField == null) {
            cinsiyetTextField = new JTextField();
            cinsiyetTextField.setBounds(740, 290, 150, 35);
        }
        return cinsiyetTextField;
    }

    public void setCinsiyetTextField(JTextField cinsiyetTextField) {
        this.cinsiyetTextField = cinsiyetTextField;
    }

    public DefaultTableModel getDTM() {
        return DTM;
    }

    public void setDTM(DefaultTableModel DTM) {
        this.DTM = DTM;
    }

    public IzleyiciController getIC() {
        return IC;
    }

    public void setIC(IzleyiciController IC) {
        this.IC = IC;
    }
    
    public ButtonGroup getCinsiyet() {

        return cinsiyet;
    }

    public void setCinsiyet(ButtonGroup cinsiyet) {
        this.cinsiyet = cinsiyet;
    }

    public JRadioButton getMaleButton() {
        if (maleButton == null) {
            maleButton = new JRadioButton("ERKEK");
            maleButton.setBounds(630, 350, 90, 60);
            maleButton.setBackground(Color.lightGray);           
        }
        return maleButton;
    }

    public void setMaleButton(JRadioButton maleButton) {
        this.maleButton = maleButton;
    }

    public JRadioButton getFemaleButton() {
        if (femaleButton == null) {
            femaleButton = new JRadioButton("KADIN");
            femaleButton.setBounds(720, 350, 90, 60);
            femaleButton.setBackground(Color.lightGray);
        }
        return femaleButton;
    }

    public void setFemaleButton(JRadioButton femaleButton) {
        this.femaleButton = femaleButton;
    }

}
