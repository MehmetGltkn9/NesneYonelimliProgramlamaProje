package GUI;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class AnaEkran extends JFrame{
    JLabel sinemaAdiLabel;
    JButton filmButonu;
    JButton seansButonu;
    JButton BiletButonu;
    
}
