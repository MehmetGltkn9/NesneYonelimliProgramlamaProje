package GUI;

import Action.AdminBiletEkranAction;
import Controller.BiletController;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class AdminBiletEkran extends JFrame {
    private JPanel panel1;
    private JPanel panel2;
    private JButton biletAl;
    private JButton biletIptal;
    private JButton GeriButon;
    private JButton[] butonlar;
    private JComboBox salonlar;
    private JLabel izleyici;

    public AdminBiletEkran() {
        Olustur();
    }

    private void Olustur() {
       add(panel1Ekle());
       add(panel2Ekle());
       setBounds(500, 200, 1000, 600);
       setVisible(true);
       setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    private JPanel panel1Ekle(){
        panel1 = getPanel1();
        panel1.setLayout(new GridLayout(6,7,5,6));
        butonlar = new JButton[42];
        BiletController BC = new BiletController();
        for(int i=0;i<42;i++){
            butonlar[i] = new JButton(String.valueOf(i+1));
            butonlar[i].addActionListener(new AdminBiletEkranAction(this));
            if(BC.getDoluMu(i)){
                butonlar[i].setBackground(new Color(255,0,0));
            }
            else{
                butonlar[i].setBackground(new Color(204,153,255));
            }            
            panel1.add(butonlar[i]);
            
        }
        panel1.setBackground(Color.LIGHT_GRAY);
        return panel1;
    }
    
    private JPanel panel2Ekle(){
        panel2 = getPanel2();
        panel2.setLayout(null);
        panel2.add(getBiletAl());
        panel2.add(getBiletIptal());
        panel2.add(getGeriButon());
        panel2.add(getSalonlar());
        panel2.setBackground(Color.LIGHT_GRAY);
        return panel2;
    }
    
    public JPanel getPanel1() {
        if(panel1 == null){
            panel1 = new JPanel();
            panel1.setBounds(0, 0, 600, 560);
        }
        return panel1;
    }

    public void setPanel1(JPanel panel1) {
        this.panel1 = panel1;
    }

    public JPanel getPanel2() {
        if(panel2 == null){
            panel2 = new JPanel();
            panel2.setBounds(600, 0, 400, 560);
        }
        return panel2;
    }

    public void setPanel2(JPanel panel2) {
        this.panel2 = panel2;
    }

    public JButton getBiletAl() {
        if(biletAl == null){
            biletAl = new JButton("Ekle");
            biletAl.setBounds(680, 500, 100, 40);
            biletAl.addActionListener(new AdminBiletEkranAction(this));
            biletAl.setBackground(Color.GRAY);
        }
        return biletAl;
    }

    public void setBiletAl(JButton biletAl) {
        this.biletAl = biletAl;
    }

    public JButton getBiletIptal() {
        if(biletIptal == null){
            biletIptal = new JButton("Iptal");
            biletIptal.setBounds(820, 500, 100, 40);
            biletIptal.addActionListener(new AdminBiletEkranAction(this));
            biletIptal.setBackground(Color.GRAY);
        }
        return biletIptal;
    }

    public void setBiletIptal(JButton biletIptal) {
        this.biletIptal = biletIptal;
    }

    public JButton[] getButonlar() {
        return butonlar;
    }

    public void setButonlar(JButton[] butonlar) {
        this.butonlar = butonlar;
    }
    
    public JButton getGeriButon() {
        if(GeriButon == null){
            GeriButon = new JButton("<--Geri--");
            GeriButon.setBounds(850, 20, 100, 40);
            GeriButon.addActionListener(new AdminBiletEkranAction(this));
            GeriButon.setBackground(Color.white);
        }
        return GeriButon;
    }

    public void setGeriButon(JButton GeriButon) {
        this.GeriButon = GeriButon;
    }

    public JComboBox getSalonlar() {
        if(salonlar == null){
            String[] salonAdlari = new String[42];
            for(int i=0;i<42;i++){
                salonAdlari[i] = "Koltuk "+(i+1);
            }
            salonlar = new JComboBox(salonAdlari);
            salonlar.addActionListener(new AdminBiletEkranAction(this));
            salonlar.setBounds(650, 20, 150, 40);
        }
        return salonlar;
    }

    public void setSalonlar(JComboBox salonlar) {
        this.salonlar = salonlar;
    }
    
    
    
}
