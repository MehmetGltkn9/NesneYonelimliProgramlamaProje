package GUI;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class TabloDeneme extends JFrame{
    private JPanel anaPanel ;
    private JTable jtable ;
    private DefaultTableModel dfm;

    public TabloDeneme() {
        Olustur();
    }
    
    public void Olustur(){
        anaPanel = new JPanel();
               
    }

    public JPanel getAnaPanel() {
        return anaPanel;
    }

    public void setAnaPanel(JPanel anaPanel) {
        this.anaPanel = anaPanel;
    }

    public JTable getJtable() {
        return jtable;
    }

    public void setJtable(JTable jtable) {
        this.jtable = jtable;
    }

    public DefaultTableModel getDfm() {
        return dfm;
    }

    public void setDfm(DefaultTableModel dfm) {
        this.dfm = dfm;
    }
    
    
}
