package GUI;

import Action.AdminAnaEkranAction;
import Action.KaydolEkraniAction;
import java.awt.Color;
import java.awt.Font;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class KaydolEkrani extends JFrame {

    private JLabel adSoyad;
    private JLabel sifre;
    private JLabel kullaniciAdi;
    private JLabel telefonno;
    private JTextField adSoyadTextField;
    private JTextField sifreTextField;
    private JTextField kullaniciAdiTextField;
    private JTextField telefonnoTextField;
    private JPanel panel;
    private JButton kaydolButonu;
    private JButton geriButon;
    private ButtonGroup cinsiyet;
    private JRadioButton maleButton;
    private JRadioButton femaleButton;

    public KaydolEkrani() {
        Olustur();
    }

    private void Olustur() {
        add(PanelEkle());
        setBounds(700, 200, 600, 600);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public JPanel PanelEkle() {
        panel = getPanel();
        panel.setLayout(null);
        panel.add(getAdSoyad());
        panel.add(getAdSoyadTextField());
        panel.add(getSifre());
        panel.add(getSifreTextField());
        panel.add(getKullaniciAdi());
        panel.add(getKullaniciAdiTextField());
        panel.add(getTelefonno());
        panel.add(getTelefonnoTextField());
        cinsiyet = new ButtonGroup();
        cinsiyet.add(getMaleButton());
        cinsiyet.add(getFemaleButton());
        panel.add(getKaydolButonu());
        panel.add(getMaleButton());
        panel.add(getFemaleButton());
        panel.add(getGeriButon());
        panel.setBackground(Color.LIGHT_GRAY);
        return panel;
    }

    public JLabel getAdSoyad() {
        if (adSoyad == null) {
            adSoyad = new JLabel("AD SOYAD");
            adSoyad.setBounds(100, 0, 400, 150);
            adSoyad.setFont(new Font("Ties New Roman", Font.BOLD, 25));
        }
        return adSoyad;
    }

    public void setAdSoyad(JLabel adSoyad) {
        this.adSoyad = adSoyad;
    }

    public JLabel getSifre() {
        if (sifre == null) {
            sifre = new JLabel("ŞİFRE");
            sifre.setBounds(350, 0, 400, 150);
            sifre.setFont(new Font("Times New Roman", Font.BOLD, 25));
        }
        return sifre;
    }

    public void setSifre(JLabel sifre) {
        this.sifre = sifre;
    }

    public JLabel getKullaniciAdi() {
        if (kullaniciAdi == null) {
            kullaniciAdi = new JLabel("KULLANICI ADI");
            kullaniciAdi.setBounds(70, 170, 400, 200);
            kullaniciAdi.setFont(new Font("Times New Roman", Font.BOLD, 25));
        }
        return kullaniciAdi;
    }

    public void setKullaniciAdi(JLabel kullaniciAdi) {
        this.kullaniciAdi = kullaniciAdi;
    }

    public JLabel getTelefonno() {
        if (telefonno == null) {
            telefonno = new JLabel("TELEFON NO");
            telefonno.setBounds(330, 170, 400, 200);
            telefonno.setFont(new Font("Times New Roman", Font.BOLD, 25));
        }
        return telefonno;
    }

    public void setTelefonno(JLabel telefonno) {
        this.telefonno = telefonno;
    }

    public JTextField getAdSoyadTextField() {
        if (adSoyadTextField == null) {
            adSoyadTextField = new JTextField();
            adSoyadTextField.setBounds(65, 130, 200, 50);
        }
        return adSoyadTextField;
    }

    public void setAdSoyadTextField(JTextField adSoyadTextField) {
        this.adSoyadTextField = adSoyadTextField;
    }

    public JTextField getSifreTextField() {
        if (sifreTextField == null) {
            sifreTextField = new JTextField();
            sifreTextField.setBounds(310, 130, 200, 50);
        }
        return sifreTextField;
    }

    public void setSifreTextField(JTextField sifreTextField) {
        this.sifreTextField = sifreTextField;
    }

    public JTextField getKullaniciAdiTextField() {
        if (kullaniciAdiTextField == null) {
            kullaniciAdiTextField = new JTextField();
            kullaniciAdiTextField.setBounds(65, 320, 200, 50);
        }
        return kullaniciAdiTextField;
    }

    public void setKullaniciAdiTextField(JTextField kullaniciAdiTextField) {
        this.kullaniciAdiTextField = kullaniciAdiTextField;
    }

    public JTextField getTelefonnoTextField() {
        if (telefonnoTextField == null) {
            telefonnoTextField = new JTextField();
            telefonnoTextField.setBounds(310, 320, 200, 50);
        }
        return telefonnoTextField;
    }

    public void setTelefonnoTextField(JTextField telefonnoTextField) {
        this.telefonnoTextField = telefonnoTextField;
    }

    public JPanel getPanel() {
        if (panel == null) {
            panel = new JPanel();
        }
        return panel;
    }

    public void setPanel(JPanel panel) {
        this.panel = panel;
    }

    public JButton getKaydolButonu() {
        if (kaydolButonu == null) {
            kaydolButonu = new JButton("KAYDOL");
            kaydolButonu.setBounds(300, 400, 200, 60);
            kaydolButonu.addActionListener(new KaydolEkraniAction(this));
            kaydolButonu.setBackground(Color.GRAY);
        }
        return kaydolButonu;
    }

    public void setKaydolButonu(JButton kaydolButonu) {
        this.kaydolButonu = kaydolButonu;
    }

    public ButtonGroup getCinsiyet() {

        return cinsiyet;
    }

    public void setCinsiyet(ButtonGroup cinsiyet) {
        this.cinsiyet = cinsiyet;
    }

    public JRadioButton getMaleButton() {
        if (maleButton == null) {
            maleButton = new JRadioButton("Erkek");
            maleButton.setBounds(150, 400, 60, 40);
            maleButton.setBackground(Color.lightGray);
        }
        return maleButton;
    }

    public void setMaleButton(JRadioButton maleButton) {
        this.maleButton = maleButton;
    }

    public JRadioButton getFemaleButton() {
        if (femaleButton == null) {
            femaleButton = new JRadioButton("Kadın");
            femaleButton.setBounds(90, 400, 60, 40);
            femaleButton.setBackground(Color.lightGray);
        }
        return femaleButton;
    }

    public void setFemaleButton(JRadioButton femaleButton) {
        this.femaleButton = femaleButton;
    }
    
    public JButton getGeriButon() {
        if(geriButon == null){
            geriButon = new JButton("<--Geri--");
            geriButon.setBounds(470, 20, 100, 40);
            geriButon.setBackground(Color.white);
            geriButon.addActionListener(new KaydolEkraniAction(this));
        }
        return geriButon;
    }

    public void setGeriButon(JButton geriButon) {
        this.geriButon = geriButon;
    }
    


}
