package GUI;

import Action.AdminAnaEkranAction;
import Action.AdminIzleyiciEkranAction;
import java.awt.Color;
import java.awt.Font;
import javax.swing.*;

public class AdminAnaEkran extends JFrame {

    private JPanel anaEkranPanel;
    private JButton filmButton;
    private JButton SeansButton;
    private JButton BiletButton;
    private JButton IzleyiciButton;
    private JButton GeriButon;
    private JLabel sinemaAdi;

    public AdminAnaEkran() {
        Olustur();
    }

    private void Olustur() {
        add(PanelEkle());
        setBounds(500, 200, 1000, 600);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public JPanel PanelEkle() {
        JPanel jpanel = getAnaEkranPanel();
        jpanel.setLayout(null);
        jpanel.add(getFilmButton());
        jpanel.add(getSeansButton());
        jpanel.add(getBiletButon());
        jpanel.add(getIzleyiciButton());
        jpanel.add(getGeriButon());
        jpanel.add(getSinemaAdi());
        jpanel.setBackground(Color.LIGHT_GRAY);
        return jpanel;
    }

    public JPanel getAnaEkranPanel() {
        if (anaEkranPanel == null) {
            anaEkranPanel = new JPanel();
            anaEkranPanel.setBounds(250, 300, 900, 600);
        }
        return anaEkranPanel;
    }

    public void setAnaEkranPanel(JPanel anaEkranPanel) {
        this.anaEkranPanel = anaEkranPanel;
    }

    public JButton getFilmButton() {
        if (filmButton == null) {
            filmButton = new JButton("Film");
            filmButton.setBounds(100, 100, 150, 150);
            filmButton.addActionListener(new AdminAnaEkranAction(this));
            filmButton.setBackground(Color.GRAY);
        }
        return filmButton;
    }

    public void setFilmButton(JButton filmButton) {
        this.filmButton = filmButton;
    }

    public JButton getSeansButton() {
        if (SeansButton == null) {
            SeansButton = new JButton("Seans");
            SeansButton.setBounds(700, 100, 150, 150);
            SeansButton.addActionListener(new AdminAnaEkranAction(this));
            SeansButton.setBackground(Color.GRAY);
        }
        return SeansButton;
    }

    public void setSeansButton(JButton SeansButton) {
        this.SeansButton = SeansButton;
    }

    public JButton getBiletButon() {
        if (BiletButton == null) {
            BiletButton = new JButton("Bilet");
            BiletButton.setBounds(500, 300, 150, 150);
            BiletButton.addActionListener(new AdminAnaEkranAction(this));
            BiletButton.setBackground(Color.GRAY);
        }
        return BiletButton;
    }

    public void setBiletButton(JButton BiletButton) {
        this.BiletButton = BiletButton;
    }

    public JButton getIzleyiciButton() {
        if (IzleyiciButton == null) {
            IzleyiciButton = new JButton("İzleyici");
            IzleyiciButton.setBounds(300, 300, 150, 150);
            IzleyiciButton.addActionListener(new AdminAnaEkranAction(this));
            IzleyiciButton.setBackground(Color.GRAY);
        }
        return IzleyiciButton;
    }

    public void setIzleyiciButton(JButton IzleyiciButton) {
        this.IzleyiciButton = IzleyiciButton;
    }

    public JButton getGeriButon() {
        if(GeriButon == null){
            GeriButon = new JButton("<--Geri--");
            GeriButon.setBounds(850, 20, 100, 40);
            GeriButon.setBackground(Color.white);
            GeriButon.addActionListener(new AdminAnaEkranAction(this));
        }
        return GeriButon;
    }

    public void setGeriButon(JButton GeriButon) {
        this.GeriButon = GeriButon;
    }
    public JLabel getSinemaAdi() {
        if (sinemaAdi == null) {
            sinemaAdi = new JLabel("YEŞİL SİNEMA");
            sinemaAdi.setBounds(350, 120, 600, 100);
            sinemaAdi.setFont(new Font("Times New Roman", Font.BOLD, 34));
        }
        return sinemaAdi;
    }

    public void setSinemaAdi(JLabel sinemaAdi) {
        this.sinemaAdi = sinemaAdi;
    }
    
}
