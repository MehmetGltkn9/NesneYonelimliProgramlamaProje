package GUI;

import Action.AdminAnaEkranAction;
import java.awt.Color;
import java.awt.Font;
import javax.swing.*;

public class AdminAnaEkran extends JFrame {

    private JPanel anaEkranPanel;

    private JButton sinemaButon;
    private JButton filmButon;
    private JButton seansButton;
    private JButton biletButton;
    private JButton musteriButton;
    private JLabel sinemaAdi;

    public AdminAnaEkran() {
        Olustur();
    }

    private void Olustur() {
        add(PanelEkle());
        setBounds(500, 200, 1000, 600);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public JPanel PanelEkle() {
        JPanel jpanel = getAnaEkranPanel();
        jpanel.setLayout(null);
        jpanel.add(getSinemaButon());
        jpanel.add(getFilmButon());
        jpanel.add(getSeansButton());
        jpanel.add(getBiletButton());
        jpanel.add(getMusteriButton());
        jpanel.add(getSinemaAdi());
        jpanel.setBackground(Color.LIGHT_GRAY);
        return jpanel;
    }

    public JPanel getAnaEkranPanel() {
        if (anaEkranPanel == null) {
            anaEkranPanel = new JPanel();
            anaEkranPanel.setBounds(250, 300, 900, 600);
        }
        return anaEkranPanel;
    }

    public void setAnaEkranPanel(JPanel anaEkranPanel) {
        this.anaEkranPanel = anaEkranPanel;
    }

    public JButton getSinemaButon() {
        if (sinemaButon == null) {
            sinemaButon = new JButton("Sinema");
            sinemaButon.setBounds(100, 100, 150, 150);
            sinemaButon.addActionListener(new AdminAnaEkranAction(this));
            sinemaButon.setBackground(Color.GRAY);
        }
        return sinemaButon;
    }

    public void setSinemaButon(JButton sinemaButon) {
        this.sinemaButon = sinemaButon;
    }

    public JButton getFilmButon() {
        if (filmButon == null) {
            filmButon = new JButton("Film");
            filmButon.setBounds(300, 100, 150, 150);
            filmButon.addActionListener(new AdminAnaEkranAction(this));
            filmButon.setBackground(Color.GRAY);
        }
        return filmButon;
    }

    public void setFilmButon(JButton filmButon) {
        this.filmButon = filmButon;
    }

    public JButton getSeansButton() {
        if (seansButton == null) {
            seansButton = new JButton("Seans");
            seansButton.setBounds(500, 100, 150, 150);
            seansButton.addActionListener(new AdminAnaEkranAction(this));
            seansButton.setBackground(Color.GRAY);
        }
        return seansButton;
    }

    public void setSeansButton(JButton seansButton) {
        this.seansButton = seansButton;
    }

    public JButton getBiletButton() {
        if (biletButton == null) {
            biletButton = new JButton("Bilet");
            biletButton.setBounds(700, 100, 150, 150);
            biletButton.addActionListener(new AdminAnaEkranAction(this));
            biletButton.setBackground(Color.GRAY);
        }
        return biletButton;
    }

    public void setBiletButton(JButton biletButton) {
        this.biletButton = biletButton;
    }

    public JButton getMusteriButton() {
        if (musteriButton == null) {
            musteriButton = new JButton("Kullanıcılar");
            musteriButton.setBounds(300, 300, 150, 150);
            musteriButton.addActionListener(new AdminAnaEkranAction(this));
            musteriButton.setBackground(Color.GRAY);
        }
        return musteriButton;
    }

    public void setMusteriButton(JButton musteriButton) {
        this.musteriButton = musteriButton;
    }

    public JLabel getSinemaAdi() {
        if (sinemaAdi == null) {
            sinemaAdi = new JLabel("YEŞİL SİNEMA");
            sinemaAdi.setBounds(400, 10, 600, 100);
            sinemaAdi.setFont(new Font("Times New Roman", Font.BOLD, 20));
        }
        return sinemaAdi;
    }

    public void setSinemaAdi(JLabel sinemaAdi) {
        this.sinemaAdi = sinemaAdi;
    }

}
