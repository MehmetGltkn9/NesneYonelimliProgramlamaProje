package GUI;

import Action.AdminSeansEkranAction;
import Controller.SeansController;
import Entity.Seans;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.table.DefaultTableModel;

public class AdminSeansEkran extends JFrame{

    private JPanel filmEkranPanel;
    private JTable tablo;
    private JScrollPane scrollPano;
    private JLabel filmLabel;
    private JLabel salonLabel;
    private JLabel tarihSaatLabel;
    private JLabel dolulukLabel;
    private JButton GeriButon;
    private JButton EkleButon;
    private JButton SilButon;
    private JTextField filmTextField;
    private JTextField salonTextField;
    private JTextField tarihSaatTextField;
    private JTextField dolulukTextField;
    private DefaultTableModel DTM;
    private Object[] tabloVeri;
    private SeansController SC;
      
    public AdminSeansEkran(){
        TabloOlustur();
        Olustur();
    } 
    
    private void Olustur() {
        add(PanelEkle());
        setBounds(500, 200, 1000, 600);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    private void TabloOlustur(){
        SC = new SeansController();
        DTM = new DefaultTableModel();
        Object[] tabloObje = new Object[4];

        tabloObje[0] = "Film Adı";
        tabloObje[1] = "Salon Adı";
        tabloObje[2] = "Tarih-Saat";
        tabloObje[3] = "Doluluk";

        DTM.setColumnIdentifiers(tabloObje);
        tabloVeri = new Object[4];

        List<Seans> seanslar = SC.ListeyiAl();
        for (int i = 0; i < seanslar.size(); i++) {
            tabloVeri[0] = seanslar.get(i).getFilm().getFilmAdi();
            tabloVeri[1] = seanslar.get(i).getSalon().getSalonNo();
            tabloVeri[2] = seanslar.get(i).getTarihSaat();
            tabloVeri[3] = seanslar.get(i).getDoluluk();
            DTM.addRow(tabloVeri);
        }

        PanelEkle();
    }

    public JPanel PanelEkle() {
        filmEkranPanel = getFilmEkranPanel();
        filmEkranPanel.setLayout(null);
        filmEkranPanel.add(getScrollPano());
        filmEkranPanel.add(getEkleButon());
        filmEkranPanel.add(getGeriButon());
        filmEkranPanel.add(getSilButon());
        filmEkranPanel.add(getFilmLabel());
        filmEkranPanel.add(getFilmTextField());
        filmEkranPanel.add(getSalonLabel());
        filmEkranPanel.add(getSalonTextField());
        filmEkranPanel.add(getTarihSaatLabel());
        filmEkranPanel.add(getTarihSaatTextField());
        filmEkranPanel.add(getDolulukLabel());
        filmEkranPanel.add(getDolulukTextField());
        filmEkranPanel.setBackground(Color.LIGHT_GRAY);
        return filmEkranPanel;
    }
     public void TabloGuncelle() {
        List<Seans> Seanslar = SC.ListeyiAl();
        DTM.setRowCount(0);
        for (int i = 0; i < Seanslar.size(); i++) {
            tabloVeri[0] = Seanslar.get(i).getFilm().getFilmAdi();
            tabloVeri[1] = Seanslar.get(i).getSalon().getSalonNo();
            tabloVeri[2] = Seanslar.get(i).getTarihSaat();
            tabloVeri[3] = Seanslar.get(i).getDoluluk();
            DTM.addRow(tabloVeri);
        }
        PanelEkle();
    }
    

    public JPanel getFilmEkranPanel() {
        if (filmEkranPanel == null) {
            filmEkranPanel = new JPanel();
            filmEkranPanel.setBounds(250, 300, 900, 600);
        }
        return filmEkranPanel;
    }

    public void setFilmEkranPanel(JPanel filmEkranPanel) {
        this.filmEkranPanel = filmEkranPanel;
    }

    public JTable getTablo() {
        if (tablo == null) {
            this.tablo = new JTable();
            tablo.setBounds(40, 40, 400, 500);
            tablo.setBackground(new Color(204,153,255));
            tablo.setModel(DTM);
        }
        return tablo;
    }

    public void setTablo(JTable tablo) {
        this.tablo = tablo;
    }

    public JButton getGeriButon() {
        if(GeriButon == null){
            GeriButon = new JButton("<--Geri--");
            GeriButon.setBounds(850, 20, 100, 40);
            GeriButon.setBackground(Color.white);
            GeriButon.addActionListener(new AdminSeansEkranAction(this));
        }
        return GeriButon;
    }

    public void setGeriButon(JButton GeriButon) {
        this.GeriButon = GeriButon;
    }

    public JButton getEkleButon() {
        if(EkleButon==null){
            EkleButon=new JButton("Ekle");
            EkleButon.setBounds(550, 370, 100, 40);
            EkleButon.setBackground(Color.GRAY);
            EkleButon.addActionListener(new AdminSeansEkranAction(this));
            EkleButon.setBackground(Color.GRAY);
        }
        return EkleButon;
    }

    public void setEkleButon(JButton EkleButon) {
        this.EkleButon = EkleButon;
    }

    public JButton getSilButon() {
        if(SilButon==null){
            SilButon=new JButton("Sil");
            SilButon.setBounds(760, 370, 100, 40);
            SilButon.addActionListener(new AdminSeansEkranAction(this));
            SilButon.setBackground(Color.GRAY);
        }
        return SilButon;
    }

    public void setSilButon(JButton SilButon) {
        this.SilButon = SilButon;
    }

    public JScrollPane getScrollPano() {
        if(scrollPano == null){
            scrollPano = new JScrollPane();
            scrollPano.setBounds(40, 40, 400, 500);
            scrollPano.setViewportView(getTablo());
        }
        return scrollPano;
    }

    public void setScrollPano(JScrollPane scrollPano) {
        this.scrollPano = scrollPano;
    }

    public JLabel getFilmLabel() {
        if (filmLabel == null) {
            filmLabel = new JLabel("FİLM ADI");
            filmLabel.setBounds(550, 60, 200, 100);
            filmLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        }
        return filmLabel;
    }

    public void setFilmLabel(JLabel filmLabel) {
        this.filmLabel = filmLabel;
    }

    public JLabel getSalonLabel() {
        if (salonLabel == null) {
            salonLabel = new JLabel("SALON");
            salonLabel.setBounds(750, 60, 200, 100);
            salonLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        }
        return salonLabel;
    }

    public void setSalonLabel(JLabel salonLabel) {
        this.salonLabel = salonLabel;
    }

    public JLabel getTarihSaatLabel() {
        if (tarihSaatLabel == null) {
            tarihSaatLabel = new JLabel("TARİH VE SAAT");
            tarihSaatLabel.setBounds(540, 200, 200, 100);
            tarihSaatLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        }

        return tarihSaatLabel;
    }

    public void setTarihSaatLabel(JLabel tarihSaatLabel) {
        this.tarihSaatLabel = tarihSaatLabel;
    }

    public JLabel getDolulukLabel() {
        if (dolulukLabel == null) {
            dolulukLabel = new JLabel("DOLULUK");
            dolulukLabel.setBounds(750, 200, 300,100);
            dolulukLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        }
        return dolulukLabel;
    }

    public void setDolulukLabel(JLabel dolulukLabel) {
        this.dolulukLabel = dolulukLabel;
    }

    public JTextField getFilmTextField() {
        if(filmTextField == null){
            filmTextField = new JTextField();
            filmTextField.setBounds(525, 150, 150, 35);
        }
        return filmTextField;
    }

    public void setFilmTextField(JTextField filmTextField) {
        this.filmTextField = filmTextField;
    }

    public JTextField getSalonTextField() {
        if(salonTextField == null){
            salonTextField = new JTextField();
            salonTextField.setBounds(740, 150, 150, 35);
        }
        return salonTextField;
    }

    public void setSalonTextField(JTextField salonTextField) {
        this.salonTextField = salonTextField;
    }

    public JTextField getTarihSaatTextField() {
        if(tarihSaatTextField == null){
            tarihSaatTextField = new JTextField();
            tarihSaatTextField.setBounds(525, 290, 150, 35);
        }
        return tarihSaatTextField;
    }

    public void setTarihSaatTextField(JTextField tarihSaatTextField) {
        this.tarihSaatTextField = tarihSaatTextField;
    }

    public JTextField getDolulukTextField() {
        if(dolulukTextField == null){
            dolulukTextField = new JTextField();
            dolulukTextField.setBounds(740, 290, 150, 35);
        }
        return dolulukTextField;
    }

    public void setDolulukTextField(JTextField dolulukTextField) {
        this.dolulukTextField = dolulukTextField;
    }

    public DefaultTableModel getDTM() {
        return DTM;
    }

    public void setDTM(DefaultTableModel DTM) {
        this.DTM = DTM;
    }

    public SeansController getSC() {
        return SC;
    }

    public void setSC(SeansController SC) {
        this.SC = SC;
    }
    
}

