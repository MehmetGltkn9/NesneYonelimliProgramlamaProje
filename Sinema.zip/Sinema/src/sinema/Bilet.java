package sinema;
import java.util.Date;
public class Bilet {
    public Izleyici biletSahibi;
    public Koltuk koltuk;
    public int koltukNo;
    public Film biletFilm;
    public Date biletTarihi;
    public int biletNo;
    public float biletFiyat;

    public Bilet(Izleyici biletSahibi, Koltuk koltuk, int koltukNo,
                 Film biletFilm, Date biletTarihi, int biletNo, float biletFiyat) {
        this.biletSahibi = biletSahibi;
        this.koltuk = koltuk;
        this.koltukNo = koltukNo;
        this.biletFilm = biletFilm;
        this.biletTarihi = biletTarihi;
        this.biletNo = biletNo;
        this.biletFiyat = biletFiyat;
    }
    
}
