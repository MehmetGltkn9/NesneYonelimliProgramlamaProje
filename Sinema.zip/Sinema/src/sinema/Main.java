package sinema;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Main {
    public static void main(String[] args) {
        ///Sinema yeniSinema = new Sinema("Maximum");
        System.out.println();
        JFrame frame = new JFrame("Merhaba butonu");
        JLabel label = new JLabel();
        JButton button = new JButton("Merhaba");
        label.setBounds(0, 0, 1920, 1080);
        button.setBounds(240, 250, 100, 40);
        button.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Merhaba Dunya");
            }     
        });
        
        
        frame.add(label);
        frame.add(button);       
        frame.setSize(1920, 1080);
        frame.setLayout(null);
        frame.setVisible(true);
        label.setVisible(true);
    }
    
}
