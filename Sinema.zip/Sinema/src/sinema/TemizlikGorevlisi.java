package sinema;
public class TemizlikGorevlisi extends Calisan{
    
    public TemizlikGorevlisi(float maas, String mesaiSaatleri, String gorev, int yetkiSeviyesi) {
        super(maas, mesaiSaatleri, gorev, yetkiSeviyesi);
    }
    
}
