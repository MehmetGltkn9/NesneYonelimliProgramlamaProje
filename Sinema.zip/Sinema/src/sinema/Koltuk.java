package sinema;
public class Koltuk {
    public int koltukNo;
    public boolean dolu;
    public Salon salon;

    public Koltuk(int koltukNo, Salon salon) {
        this.koltukNo = koltukNo;
        this.dolu = false;
        this.salon = salon;
    }
    
}
