package sinema;
public class GiseGorevlisi extends Calisan {
    
    public GiseGorevlisi(float maas, String mesaiSaatleri, String gorev, int yetkiSeviyesi) {
        super(maas, mesaiSaatleri, gorev, yetkiSeviyesi);
    }
    
}
