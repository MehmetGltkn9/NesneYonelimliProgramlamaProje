package sinema;
public class Mudur extends Calisan{
    
    public Mudur(float maas, String mesaiSaatleri, String gorev, int yetkiSeviyesi) {
        super(maas, mesaiSaatleri, gorev, yetkiSeviyesi);
    }
    
}
