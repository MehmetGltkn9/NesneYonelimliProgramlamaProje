package sinema;
public class Izleyici {
    public String izleyiciAdSoyad;
    public char izleyiciCinsiyeti;
    public String izleyiciTuru;
    public String izleyiciE_Mail;
    public String izleyiciTelefonNo;
    public Bilet izleyiciBilet;

    public Izleyici(String izleyiciAdSoyad, char izleyiciCinsiyeti,
                    String izleyiciTuru, String izleyiciE_Mail, String izleyiciTelefonNo) {
        this.izleyiciAdSoyad = izleyiciAdSoyad;
        this.izleyiciCinsiyeti = izleyiciCinsiyeti;
        this.izleyiciTuru = izleyiciTuru;
        this.izleyiciE_Mail = izleyiciE_Mail;
        this.izleyiciTelefonNo = izleyiciTelefonNo;
    }
    
}
