package sinema;
public class Salon {
    public int salonNo;
    public String salonTuru;
    public int izleyiciKapasitesi;
    public int izleyiciSayisi;
    public int katNo;
    public int doluluk;
    public Film gosterilenFilm;
    
    public Salon(int salonNo,String salonTuru,int izleyiciKapasitesi,
                int izleyiciSayisi,int katNo,int doluluk){
        this.salonNo = salonNo;
        this.salonTuru = salonTuru;
        this.izleyiciKapasitesi = izleyiciKapasitesi;
        this.izleyiciSayisi = izleyiciSayisi;
        this.katNo = katNo;
        this.doluluk = doluluk;
    }
    public Salon(){
        
    }
    public int getSalonNo() {
        return salonNo;
    }

    public void setSalonNo(int salonNo) {
        this.salonNo = salonNo;
    }

    public String getSalonTuru() {
        return salonTuru;
    }

    public void setSalonTuru(String salonTuru) {
        this.salonTuru = salonTuru;
    }

    public int getIzleyiciKapasitesi() {
        return izleyiciKapasitesi;
    }

    public void setIzleyiciKapasitesi(int izleyiciKapasitesi) {
        this.izleyiciKapasitesi = izleyiciKapasitesi;
    }

    public int getIzleyiciSayisi() {
        return izleyiciSayisi;
    }

    public void setIzleyiciSayisi(int izleyiciSayisi) {
        this.izleyiciSayisi = izleyiciSayisi;
    }

    public int getKatNo() {
        return katNo;
    }

    public void setKatNo(int katNo) {
        this.katNo = katNo;
    }

    public int getDoluluk() {
        return doluluk;
    }

    public void setDoluluk(int doluluk) {
        this.doluluk = doluluk;
    }

    public Film getGosterilenFilm() {
        return gosterilenFilm;
    }

    public void setGosterilenFilm(Film gosterilenFilm) {
        this.gosterilenFilm = gosterilenFilm;
    }
    
}
