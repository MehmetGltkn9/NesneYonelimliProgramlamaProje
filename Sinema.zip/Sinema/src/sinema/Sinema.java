package sinema;

import java.time.LocalTime;
import java.util.List;
import java.util.Scanner;

public class Sinema {
    public String sinemaAdi;
    public int salonSayisi;
    public Salon Salonlar[];
    public List<Calisan> calisanlar;
    public List<Film> filmler;
    public List<LocalTime> seansSaatleri;
    
    public Sinema(String sinemaAdi){
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Salon Sayisini Giriniz: ");
        salonSayisi=scanner.nextInt();
        Salonlar = new Salon[salonSayisi];
        this.sinemaAdi = sinemaAdi;
        for(int i=0;i<salonSayisi;i++){
            Salonlar[i] = new Salon();
            
            System.out.println((i+1)+ ". Salon no giriniz: ");
            Salonlar[i].setSalonNo(scanner.nextInt());
            
            System.out.println((i+1)+ ". Salon Turu giriniz: ");            
            Salonlar[i].setSalonTuru(scanner.next());
            
            System.out.println((i + 1)+ ". Izleyici kapasitesi  giriniz: ");            
            Salonlar[i].setIzleyiciKapasitesi(scanner.nextInt());
            
            System.out.println((i+1)+ ". Kat no giriniz: ");
            Salonlar[i].setKatNo(scanner.nextInt());
            
        }
    }
    
}
