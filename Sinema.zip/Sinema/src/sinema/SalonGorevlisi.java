package sinema;
public class SalonGorevlisi extends Calisan{
    
    public SalonGorevlisi(float maas, String mesaiSaatleri, String gorev, int yetkiSeviyesi) {
        super(maas, mesaiSaatleri, gorev, yetkiSeviyesi);
    }
    
}
