package sinema;
public class Calisan {
    public float maas;
    public String mesaiSaatleri;
    public String gorev;
    public int yetkiSeviyesi;
    public boolean izinli;

    public Calisan(float maas, String mesaiSaatleri, String gorev,
                    int yetkiSeviyesi) {
        this.maas = maas;
        this.mesaiSaatleri = mesaiSaatleri;
        this.gorev = gorev;
        this.yetkiSeviyesi = yetkiSeviyesi;
        this.izinli =false;
    }
    
}
