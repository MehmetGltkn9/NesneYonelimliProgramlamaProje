package sinema;
import java.util.Date;
public class Film {
    public String filmAdi;
    public float filmSuresi;
    public float filmGecenSure;
    public float filmUcreti;
    public String filmTuru;
    public Date tarih;

    public Film(String filmAdi, float filmSuresi, float filmUcreti,
                String filmTuru, Date tarih) {
        this.filmAdi = filmAdi;
        this.filmSuresi = filmSuresi;
        this.filmUcreti = filmUcreti;
        this.filmTuru = filmTuru;
        this.tarih = tarih;
    }
    
    
}
