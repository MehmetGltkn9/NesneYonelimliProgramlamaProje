package Controller;

import DAO.IzleyiciDao;
import DAO.SeansDao;
import Entity.Izleyici;
import java.io.IOException;
import java.util.List;

public class IzleyiciController {

    public List<Izleyici> ListeyiAl() {
        IzleyiciDao izleyiciDao = new IzleyiciDao();
        List<Izleyici> izleyiciler = izleyiciDao.ListeyiAl();
        return izleyiciler;
    }

    public void Olustur(String adSoyad,char cinsiyet,String telefonNo,String kullaniciAdi,String sifre){
        Izleyici izleyici = new Izleyici(adSoyad,cinsiyet,telefonNo,kullaniciAdi,sifre);
        IzleyiciDao izleyiciDao = new IzleyiciDao();
        izleyiciDao.Olustur(izleyici);
    }

    public void Sil(int selectedRow) {
        IzleyiciDao izleyiciDao = new IzleyiciDao();
        izleyiciDao.Sil(selectedRow);
    }

}
