package Controller;

import DAO.FilmDao;
import Entity.Film;
import java.io.IOException;
import java.util.List;

public class FilmController {
    
    public void Olustur(String filmAdi, String filmYonetmen, int filmSuresi, String filmTuru){
        Film film = new Film(filmAdi,filmYonetmen,filmSuresi,filmTuru);
        FilmDao filmDao = new FilmDao();
        filmDao.Olustur(film);
    }
    
    public void Al() {
        
    }
    
    public List<Film> ListeyiAl(){
        FilmDao filmDao = new FilmDao();
        List<Film> filmler = filmDao.ListeyiAl(); 
        return filmler;
    }

    public void Sil(int selectedRow) {
        FilmDao filmDao = new FilmDao();
        filmDao.Sil(selectedRow);
    }
}
