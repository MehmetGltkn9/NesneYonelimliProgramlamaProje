package Controller;

import DAO.FilmDao;
import DAO.SeansDao;
import Entity.Film;
import Entity.Salon;
import Entity.Seans;
import java.io.IOException;
import java.util.List;

public class SeansController {

    public List<Seans> ListeyiAl() {
        SeansDao seansDao = new SeansDao();
        List<Seans> seanslar = seansDao.ListeyiAl();
        return seanslar;      
    }

    public void Olustur(String film, String salon, String tarihSaat, String doluluk) throws IOException {
        Seans seans = new Seans(new Film(film),new Salon(Integer.parseInt(salon)),tarihSaat,Integer.parseInt(doluluk));
        SeansDao seansDao = new SeansDao();
        seansDao.Olustur(seans);
    }

    public void Sil(int selectedRow) {
        SeansDao seansDao = new SeansDao();
        seansDao.Sil(selectedRow);
    }
}
