package Controller;

import DAO.BiletDao;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BiletController {

    public void SalonDegistir(int i) {
        BiletDao biletDao = new BiletDao();
        biletDao.SalonDegistir(i);
    }

    public boolean getDoluMu(int i) {
        BiletDao biletDao = new BiletDao();
        return biletDao.getDoluMu(i+1);        
    }

    public void setDoluMu(int j) {
        BiletDao biletDao = new BiletDao();
        try { 
            biletDao.setDoluMu(j+1);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(BiletController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setBos(int j) {
        BiletDao biletDao = new BiletDao();
        try { 
            biletDao.setBos(j+1);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(BiletController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
