package Controller;

import DAO.KullanıcılarDao;
import Entity.Kullanici;
import java.io.IOException;

public class KullaniciController {
    
    public boolean Kontrol(String kullaniciAdi,String sifre) throws IOException{
        Kullanici kullanici = new Kullanici(kullaniciAdi,sifre);
        KullanıcılarDao kullanıcılarDao = new KullanıcılarDao();
        if(kullanıcılarDao.Kontrol(kullanici)){
            return true;
        }
        return false;
    }  
    
    public void Olustur(String adSoyad,char cinsiyet,String telNo,String kullaniciAdi,String sifre) throws IOException{
        Kullanici kullanici = new Kullanici(adSoyad, cinsiyet, telNo, kullaniciAdi, sifre);
        KullanıcılarDao kullanıcılarDao = new KullanıcılarDao();
        kullanıcılarDao.Olustur(kullanici.toString());    
    }
    
}
