package Entity;
import java.util.ArrayList;
import java.util.Date;
public class Film {
    private String filmAdi;
    private String yonetmen;
    private int filmSuresi;
    private String filmTuru;
    private ArrayList<Seans> seanslar;

    public String getFilmAdi() {
        return filmAdi;
    }

    public void setFilmAdi(String filmAdi) {
        this.filmAdi = filmAdi;
    }

    public float getFilmSuresi() {
        return filmSuresi;
    }

    public void setFilmSuresi(int filmSuresi) {
        this.filmSuresi = filmSuresi;
    }

    public String getFilmTuru() {
        return filmTuru;
    }

    public void setFilmTuru(String filmTuru) {
        this.filmTuru = filmTuru;
    }

    public String getYonetmen() {
        return yonetmen;
    }

    public void setYonetmen(String yonetmen) {
        this.yonetmen = yonetmen;
    }

    public Film() {
        
    }

    public Film(String filmAdi) {
        this.filmAdi = filmAdi;
    }

    public Film(String filmAdi, String yonetmen, int filmSuresi, String filmTuru) {
        this.filmAdi = filmAdi;
        this.yonetmen = yonetmen;
        this.filmSuresi = filmSuresi;
        this.filmTuru = filmTuru;
    }

    private void SeansEkle(){
        
    }
    
    private void SeansSil(){
        
    }
    
    private void SeansBilgisi(){
        
    }

    @Override
    public String toString() {
        return filmAdi + ";" + yonetmen + ";" + filmSuresi + ";" + filmTuru;
    }
    
    
}
