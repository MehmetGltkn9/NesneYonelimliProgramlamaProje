package Entity;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Seans {
    private Film film;
    private Salon salon;
    private String tarihSaat;
    private int doluluk;

    public Seans(Film film, Salon salon, String tarihSaat, int doluluk) {
        this.film = film;
        this.salon = salon;
        this.tarihSaat = tarihSaat;
        this.doluluk = doluluk;
    }

    public Seans() {
    }

    public Film getFilm() {
        return film;
    }

    public void setFilm(Film film) {
        this.film = film;
    }

    public Salon getSalon() {
        return salon;
    }

    public void setSalon(Salon salon) {
        this.salon = salon;
    }

    public String getTarihSaat() {
        return tarihSaat;
    }

    public void setTarihSaat(String tarihSaat) {
        this.tarihSaat = tarihSaat;
    }

    public int getDoluluk() {
        return doluluk;
    }

    public void setDoluluk(int doluluk) {
        this.doluluk = doluluk;
    }


    private void BiletAl(){
        
    }
    private void BiletIptal(){
        
    }
    private void SeansBilgisi(){
        
    }

    @Override
    public String toString() {
        return film.getFilmAdi() + ";" + salon.getSalonNo() + ";" + tarihSaat + ";" +doluluk;
    }
    
    
}
