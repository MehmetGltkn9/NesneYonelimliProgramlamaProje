package Entity;
public class Izleyici extends Kullanici{
    private Bilet izleyiciBilet;
    public Object getAdSoyad;

    public Izleyici() {
        
    }

    public Izleyici(String adSoyad, char cinsiyet, String telefonNo, String kullaniciAdi, String sifre) {
        super(adSoyad, cinsiyet, telefonNo, kullaniciAdi, sifre);
    }

    public Izleyici(String adSoyad, char cinsiyet, String telefonNo, String kullaniciAdi) {
        super(adSoyad, cinsiyet, telefonNo, kullaniciAdi);
    }
    
    
    
    public void BiletSatinAl(){
        
    }
    
    public void BiletIptal(){
        
    }
    
    public void IzleyiciBilgileri(){
        
    }

    public Bilet getIzleyiciBilet() {
        return izleyiciBilet;
    }

    public void setIzleyiciBilet(Bilet izleyiciBilet) {
        this.izleyiciBilet = izleyiciBilet;
    }
    
    
}
