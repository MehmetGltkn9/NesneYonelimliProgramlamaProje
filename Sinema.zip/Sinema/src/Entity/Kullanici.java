package Entity;

public class Kullanici {
    private String adSoyad;
    private char cinsiyet;
    private String telefonNo;
    private String kullaniciAdi;
    private String sifre;

    public Kullanici() {
        
    }

    public Kullanici(String kullaniciAdi, String sifre) {
        this.kullaniciAdi = kullaniciAdi;
        this.sifre = sifre;
    }

    public Kullanici(String adSoyad, char cinsiyet, String telefonNo, String kullaniciAdi) {
        this.adSoyad = adSoyad;
        this.cinsiyet = cinsiyet;
        this.telefonNo = telefonNo;
        this.kullaniciAdi = kullaniciAdi;
    }
    
    

    public Kullanici(String adSoyad, char cinsiyet, String telefonNo, String kullaniciAdi, String sifre) {
        this.adSoyad = adSoyad;
        this.cinsiyet = cinsiyet;
        this.telefonNo = telefonNo;
        this.kullaniciAdi = kullaniciAdi;
        this.sifre = sifre;
    }

    public String getSifre() {
        return sifre;
    }

    public void setSifre(String sifre) {
        this.sifre = sifre;
    }

    public String getAdSoyad() {
        return adSoyad;
    }

    public void setAdSoyad(String adSoyad) {
        this.adSoyad = adSoyad;
    }

    public char getCinsiyet() {
        return cinsiyet;
    }

    public void setCinsiyet(char cinsiyet) {
        this.cinsiyet = cinsiyet;
    }

    public String getTelefonNo() {
        return telefonNo;
    }

    public void setTelefonNo(String telefonNo) {
        this.telefonNo = telefonNo;
    }

    public String getKullaniciAdi() {
        return kullaniciAdi;
    }

    public void setKullaniciAdi(String kullaniciAdi) {
        this.kullaniciAdi = kullaniciAdi;
    }

    @Override
    public String toString() {
        return adSoyad+";"+cinsiyet+";"+telefonNo+";"+kullaniciAdi+";"+sifre;
    }
    
    
}
