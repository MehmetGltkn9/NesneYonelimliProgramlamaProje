package Entity;

import java.time.LocalTime;
import java.util.List;
import java.util.Scanner;

public class Sinema {
    private String sinemaAdi;
    private int salonSayisi;
    private Salon Salonlar[];
    private List<Film> filmler;
    private List<LocalTime> seansSaatleri;

    public Sinema() {
        
    }

    public Sinema(String sinemaAdi, int salonSayisi, Salon[] Salonlar, List<Film> filmler, List<LocalTime> seansSaatleri) {
        this.sinemaAdi = sinemaAdi;
        this.salonSayisi = salonSayisi;
        this.Salonlar = Salonlar;
        this.filmler = filmler;
        this.seansSaatleri = seansSaatleri;
    }

    public List<LocalTime> getSeansSaatleri() {
        return seansSaatleri;
    }

    public void setSeansSaatleri(List<LocalTime> seansSaatleri) {
        this.seansSaatleri = seansSaatleri;
    }

    public String getSinemaAdi() {
        return sinemaAdi;
    }

    public void setSinemaAdi(String sinemaAdi) {
        this.sinemaAdi = sinemaAdi;
    }

    public int getSalonSayisi() {
        return salonSayisi;
    }

    public void setSalonSayisi(int salonSayisi) {
        this.salonSayisi = salonSayisi;
    }

    public Salon[] getSalonlar() {
        return Salonlar;
    }

    public void setSalonlar(Salon[] Salonlar) {
        this.Salonlar = Salonlar;
    }

    public List<Film> getFilmler() {
        return filmler;
    }

    public void setFilmler(List<Film> filmler) {
        this.filmler = filmler;
    }
    
    public void FilmEkle(){
        Film film = new Film();
        System.out.println("Film adi giriniz:");
        Scanner scan =  new Scanner(System.in);
        film.setFilmAdi(scan.next());
        System.out.println("Film suresi giriniz:");
        //film.setFilmSuresi();
        film.setFilmTuru(sinemaAdi);
        //film.setOyuncular(oyuncular);
        film.setYonetmen(sinemaAdi);
        filmler.add(film);
    }
    
    public void FilmCikar(){
        
    }
            
    public void SeansEkle(){
        
    }
    
    public void SeansCikar(){
        
    }
}
