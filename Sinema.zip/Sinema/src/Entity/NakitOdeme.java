package Entity;

public class NakitOdeme extends Odeme{
    
    @Override
    public void OdemeYap() {
        
    }

    @Override
    public void OdemeSorgula() {
        
    }
    
}
